import Link from "next/link";
import { notFound } from "next/navigation";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { BackToTop } from "@/components/site/back-to-top";
import { checkAdmin } from "@/lib/admin-guard";
import { db } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ArrowLeft, Pencil, Eye, ExternalLink } from "lucide-react";
import { AdminGroupEditForm } from "./admin-group-edit-form";

export const dynamic = "force-dynamic";
export const metadata = {
  title: { absolute: "Editar grupo — Admin ConectaGrupos" },
  description: "Editar un grupo individual.",
  robots: { index: false, follow: false },
};

export default async function AdminGroupEditPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { csrfToken, adminUser } = await checkAdmin();
  const { id } = await params;

  const group = await db.group.findUnique({
    where: { id },
    select: {
      id: true,
      groupName: true,
      slug: true,
      joinLink: true,
      description: true,
      category: true,
      categoryId: true,
      country: true,
      countryId: true,
      city: true,
      keywords: true,
      tags: true,
      profileImage: true,
      language: true,
      status: true,
      linkStatus: true,
      isAdult: true,
      clicks: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  if (!group) notFound();

  const [categories, countries] = await Promise.all([
    db.category.findMany({ orderBy: { sortOrder: "asc" }, select: { id: true, name: true, isAdult: true } }),
    db.country.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true } }),
  ]);

  return (
    <div className="flex min-h-screen flex-col bg-muted/30">
      <SiteHeader />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-6 sm:py-8">
          {/* Top bar */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <Button asChild variant="ghost" size="sm" className="text-muted-foreground">
                <Link href="/admin/grupos">
                  <ArrowLeft className="h-4 w-4" />
                  Volver a grupos
                </Link>
              </Button>
              <div>
                <h1 className="flex items-center gap-2 text-xl font-bold tracking-tight sm:text-2xl">
                  <Pencil className="h-5 w-5 text-emerald-600" />
                  Editar grupo
                </h1>
                <p className="text-sm text-muted-foreground">
                  <span className="font-mono text-xs">{group.id}</span>
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button asChild variant="outline" size="sm">
                <Link href={`/grupo/${group.slug}`} target="_blank">
                  <Eye className="h-3.5 w-3.5" />
                  Ver en sitio
                  <ExternalLink className="h-3 w-3 opacity-50" />
                </Link>
              </Button>
            </div>
          </div>

          {/* Group header card */}
          <Card className="mt-4 border-emerald-200/60">
            <CardHeader>
              <CardTitle className="text-lg">{group.groupName}</CardTitle>
              <CardDescription>
                <span className="font-mono text-xs text-muted-foreground">/grupo/{group.slug}</span>
                {" · "}
                Creado {new Date(group.createdAt).toLocaleDateString("es-ES")}
                {" · "}
                {group.clicks.toLocaleString("es-ES")} clicks
              </CardDescription>
            </CardHeader>
          </Card>

          {/* Edit form */}
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-base">Campos editables</CardTitle>
              <CardDescription>
                Todos los cambios quedan registrados en la auditoría como {adminUser}.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AdminGroupEditForm
                group={group}
                categories={categories}
                countries={countries}
                csrfToken={csrfToken}
              />
            </CardContent>
          </Card>
        </div>
      </main>
      <SiteFooter />
      <BackToTop />
    </div>
  );
}
