import { NextRequest, NextResponse } from "next/server";
import { checkAdminApi, checkCsrfApi, logAdminAction } from "@/lib/admin-guard";
import { db } from "@/lib/db";
import { generateSlug } from "@/lib/slug";

export const dynamic = "force-dynamic";

interface Body {
  name?: string;
  slug?: string;
  icon?: string;
  color?: string;
  description?: string;
  isAdult?: boolean;
  isActive?: boolean;
  sortOrder?: number;
  csrf?: string;
}

export async function POST(req: NextRequest) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  let body: Body = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Cuerpo inválido." }, { status: 400 });
  }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  const name = String(body.name || "").trim();
  if (!name) {
    return NextResponse.json({ ok: false, error: "Nombre obligatorio." }, { status: 400 });
  }

  let slug = String(body.slug || "").trim();
  if (!slug) slug = generateSlug(name);

  // ensure slug unique
  const existing = await db.category.findUnique({ where: { slug }, select: { id: true } });
  if (existing) {
    return NextResponse.json(
      { ok: false, error: `Ya existe una categoría con slug "${slug}".` },
      { status: 409 }
    );
  }

  const created = await db.category.create({
    data: {
      name,
      slug,
      icon: String(body.icon || "💬"),
      color: String(body.color || "emerald"),
      description: String(body.description || "").slice(0, 300),
      isAdult: Boolean(body.isAdult),
      isActive: body.isActive !== false,
      sortOrder: Number.isFinite(body.sortOrder) ? Number(body.sortOrder) : 1000,
      source: "admin",
    },
  });

  await logAdminAction("categoria.create", created.id, name);

  return NextResponse.json({ ok: true, id: created.id, slug: created.slug });
}
