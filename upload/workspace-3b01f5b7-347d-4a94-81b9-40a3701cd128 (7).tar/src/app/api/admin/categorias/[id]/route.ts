import { NextRequest, NextResponse } from "next/server";
import { checkAdminApi, checkCsrfApi, logAdminAction } from "@/lib/admin-guard";
import { db } from "@/lib/db";
import { generateSlug } from "@/lib/slug";

export const dynamic = "force-dynamic";

interface RouteParams {
  params: Promise<{ id: string }>;
}

interface Body {
  name?: string;
  slug?: string;
  icon?: string;
  color?: string;
  description?: string;
  isAdult?: boolean;
  isActive?: boolean;
  sortOrder?: number;
  csrf?: string;
}

export async function PUT(req: NextRequest, { params }: RouteParams) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  const { id } = await params;

  let body: Body = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Cuerpo inválido." }, { status: 400 });
  }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  const existing = await db.category.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json({ ok: false, error: "Categoría no encontrada." }, { status: 404 });
  }

  const name = body.name !== undefined ? String(body.name).trim() : existing.name;
  let slug = body.slug !== undefined ? String(body.slug).trim() : existing.slug;
  if (!slug) slug = generateSlug(name);

  if (slug !== existing.slug) {
    const owner = await db.category.findUnique({ where: { slug }, select: { id: true } });
    if (owner && owner.id !== id) {
      return NextResponse.json(
        { ok: false, error: `Slug "${slug}" ya está en uso.` },
        { status: 409 }
      );
    }
  }

  const updated = await db.category.update({
    where: { id },
    data: {
      name,
      slug,
      icon: body.icon !== undefined ? String(body.icon) : existing.icon,
      color: body.color !== undefined ? String(body.color) : existing.color,
      description: body.description !== undefined ? String(body.description).slice(0, 300) : existing.description,
      isAdult: body.isAdult !== undefined ? Boolean(body.isAdult) : existing.isAdult,
      isActive: body.isActive !== undefined ? Boolean(body.isActive) : existing.isActive,
      sortOrder: body.sortOrder !== undefined ? Number(body.sortOrder) : existing.sortOrder,
    },
  });

  // Sync denormalized category name on all groups if name changed
  if (name !== existing.name) {
    await db.group.updateMany({
      where: { categoryId: id },
      data: { category: name },
    });
  }

  await logAdminAction("categoria.update", id, name);

  return NextResponse.json({ ok: true, slug: updated.slug });
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  const { id } = await params;

  let body: { csrf?: string } = {};
  try {
    body = await req.json();
  } catch { /* empty OK */ }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  const existing = await db.category.findUnique({
    where: { id },
    select: { id: true, name: true },
  });
  if (!existing) {
    return NextResponse.json({ ok: false, error: "Categoría no encontrada." }, { status: 404 });
  }

  // Count groups using this category
  const count = await db.group.count({ where: { categoryId: id } });
  if (count > 0) {
    return NextResponse.json(
      {
        ok: false,
        error: `No se puede eliminar: ${count} grupo(s) usan esta categoría. Reasigna primero.`,
      },
      { status: 409 }
    );
  }

  await db.category.delete({ where: { id } });

  await logAdminAction("categoria.delete", id, existing.name);

  return NextResponse.json({ ok: true });
}
