import { NextRequest, NextResponse } from "next/server";
import { checkAdminApi, checkCsrfApi, logAdminAction } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

interface RouteParams {
  params: Promise<{ id: string }>;
}

type Action = "block" | "unblock" | "remove";

export async function POST(req: NextRequest, { params }: RouteParams) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  const { id } = await params;

  let body: { action?: Action; csrf?: string; reason?: string } = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { ok: false, error: "Cuerpo inválido." },
      { status: 400 }
    );
  }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  if (!body.action || !["block", "unblock", "remove"].includes(body.action)) {
    return NextResponse.json(
      { ok: false, error: "Acción no válida." },
      { status: 400 }
    );
  }

  const contributor = await db.ugcContributor.findUnique({
    where: { id },
    select: { id: true, displayName: true, isBlocked: true, isRemoved: true },
  });
  if (!contributor) {
    return NextResponse.json(
      { ok: false, error: "Colaborador no encontrado." },
      { status: 404 }
    );
  }

  const reason = String(body.reason || "").slice(0, 240);

  if (body.action === "block") {
    await db.ugcContributor.update({
      where: { id },
      data: { isBlocked: true, blockedReason: reason || "Bloqueado por administración" },
    });
  } else if (body.action === "unblock") {
    await db.ugcContributor.update({
      where: { id },
      data: {
        isBlocked: false,
        isRemoved: false,
        blockedReason: "",
        removeReason: "",
      },
    });
  } else if (body.action === "remove") {
    await db.ugcContributor.update({
      where: { id },
      data: {
        isRemoved: true,
        removeReason: reason || "Eliminado por administración",
        removedAt: new Date(),
      },
    });
  }

  await logAdminAction(`contributor.${body.action}`, id, contributor.displayName);

  return NextResponse.json({ ok: true });
}
