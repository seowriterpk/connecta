import { NextRequest, NextResponse } from "next/server";
import { checkAdminApi, checkCsrfApi, logAdminAction } from "@/lib/admin-guard";
import { db } from "@/lib/db";
import { generateSlug, makeUniqueSlug } from "@/lib/slug";

export const dynamic = "force-dynamic";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function PUT(req: NextRequest, { params }: RouteParams) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  const { id } = await params;

  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { ok: false, error: "Cuerpo inválido." },
      { status: 400 }
    );
  }

  const csrfErr = await checkCsrfApi(body.csrf as string | undefined);
  if (csrfErr) return csrfErr;

  const existing = await db.group.findUnique({
    where: { id },
    select: { id: true, slug: true, groupName: true },
  });
  if (!existing) {
    return NextResponse.json(
      { ok: false, error: "Grupo no encontrado." },
      { status: 404 }
    );
  }

  // Required fields
  const groupName = String(body.groupName || "").trim();
  const joinLink = String(body.joinLink || "").trim();
  if (!groupName || !joinLink) {
    return NextResponse.json(
      { ok: false, error: "Nombre y enlace son obligatorios." },
      { status: 400 }
    );
  }

  // Slug: regenerate if changed/empty, ensure unique
  let slug = String(body.slug || "").trim();
  if (!slug) slug = generateSlug(groupName);
  if (slug !== existing.slug) {
    const slugOwner = await db.group.findUnique({
      where: { slug },
      select: { id: true },
    });
    if (slugOwner && slugOwner.id !== id) {
      slug = makeUniqueSlug(slug, (s) => {
        // sync check: not perfect, but we'll do an async one below
        return false;
      });
      // Async uniqueness check
      const conflicting = await db.group.findUnique({ where: { slug }, select: { id: true } });
      if (conflicting && conflicting.id !== id) {
        // append short suffix
        slug = `${slug}-${id.slice(-4)}`;
      }
    }
  }

  // Resolve category + country names (denormalized fields)
  const categoryId = String(body.categoryId || "");
  const countryId = String(body.countryId || "");
  if (!categoryId || !countryId) {
    return NextResponse.json(
      { ok: false, error: "Categoría y país son obligatorios." },
      { status: 400 }
    );
  }
  const [category, country] = await Promise.all([
    db.category.findUnique({ where: { id: categoryId }, select: { name: true, isAdult: true } }),
    db.country.findUnique({ where: { id: countryId }, select: { name: true } }),
  ]);
  if (!category) {
    return NextResponse.json({ ok: false, error: "Categoría no válida." }, { status: 400 });
  }
  if (!country) {
    return NextResponse.json({ ok: false, error: "País no válido." }, { status: 400 });
  }

  // Arrays
  const tags = Array.isArray(body.tags)
    ? (body.tags as unknown[]).map(String).map((s) => s.trim()).filter(Boolean)
    : [];
  const keywords = Array.isArray(body.keywords)
    ? (body.keywords as unknown[]).map(String).map((s) => s.trim()).filter(Boolean)
    : [];

  // Validate enums
  const allowedStatus = ["live", "pending", "rejected", "flagged", "pruned"];
  const allowedLink = ["active", "revoked", "unknown"];
  const status = allowedStatus.includes(String(body.status)) ? String(body.status) : "pending";
  const linkStatus = allowedLink.includes(String(body.linkStatus)) ? String(body.linkStatus) : "active";

  const updated = await db.group.update({
    where: { id },
    data: {
      groupName,
      slug,
      joinLink,
      description: String(body.description || "").slice(0, 1200),
      categoryId,
      category: category.name,
      countryId,
      country: country.name,
      city: body.city ? String(body.city).slice(0, 120) : null,
      tags: JSON.stringify(tags),
      keywords: JSON.stringify(keywords),
      profileImage: body.profileImage ? String(body.profileImage) : null,
      language: String(body.language || "Espanol"),
      status,
      linkStatus,
      isAdult: Boolean(body.isAdult) || category.isAdult,
    },
  });

  await logAdminAction("grupos.update", id, groupName);

  return NextResponse.json({ ok: true, slug: updated.slug });
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  const { id } = await params;

  let body: { csrf?: string } = {};
  try {
    body = await req.json();
  } catch {
    // empty body OK
  }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  const existing = await db.group.findUnique({
    where: { id },
    select: { id: true, groupName: true, status: true },
  });
  if (!existing) {
    return NextResponse.json(
      { ok: false, error: "Grupo no encontrado." },
      { status: 404 }
    );
  }

  // Soft-delete: status → rejected
  await db.group.update({
    where: { id },
    data: { status: "rejected" },
  });

  await logAdminAction("grupos.delete", id, existing.groupName);

  return NextResponse.json({ ok: true });
}
