import { NextRequest, NextResponse } from "next/server";
import { checkAdminApi, checkCsrfApi, logAdminAction } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

interface Body {
  pageType?: string;
  entityId?: string;
  metaTitleOverride?: string;
  metaDescriptionOverride?: string;
  robotsOverride?: string;
  csrf?: string;
}

export async function POST(req: NextRequest) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  let body: Body = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Cuerpo inválido." }, { status: 400 });
  }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  const pageType = String(body.pageType || "").trim();
  const entityId = String(body.entityId || "").trim();
  if (!pageType || !entityId) {
    return NextResponse.json(
      { ok: false, error: "pageType y entityId son obligatorios." },
      { status: 400 }
    );
  }

  const existing = await db.seoOverride.findUnique({
    where: { pageType_entityId: { pageType, entityId } },
  });
  if (existing) {
    return NextResponse.json(
      { ok: false, error: "Ya existe un override para esta entidad." },
      { status: 409 }
    );
  }

  const created = await db.seoOverride.create({
    data: {
      pageType,
      entityId,
      metaTitleOverride: body.metaTitleOverride?.slice(0, 120) || null,
      metaDescriptionOverride: body.metaDescriptionOverride?.slice(0, 300) || null,
      robotsOverride: body.robotsOverride?.slice(0, 80) || null,
    },
  });

  await logAdminAction("seo.override.create", String(created.id), `${pageType}:${entityId}`);

  return NextResponse.json({ ok: true, id: created.id });
}
