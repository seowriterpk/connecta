import { NextRequest, NextResponse } from "next/server";
import { checkAdminApi, checkCsrfApi, logAdminAction } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

interface RouteParams {
  params: Promise<{ id: string }>;
}

interface Body {
  entityType?: string;
  entityName?: string;
  customTitle?: string;
  customHeroDesc?: string;
  customIntro?: string;
  csrf?: string;
}

export async function PUT(req: NextRequest, { params }: RouteParams) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  const { id } = await params;
  const numId = Number(id);
  if (!Number.isFinite(numId)) {
    return NextResponse.json({ ok: false, error: "ID inválido." }, { status: 400 });
  }

  let body: Body = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Cuerpo inválido." }, { status: 400 });
  }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  const existing = await db.entityIntro.findUnique({ where: { id: numId } });
  if (!existing) {
    return NextResponse.json({ ok: false, error: "Intro no encontrado." }, { status: 404 });
  }

  await db.entityIntro.update({
    where: { id: numId },
    data: {
      customTitle: body.customTitle !== undefined ? (body.customTitle?.slice(0, 120) || null) : existing.customTitle,
      customHeroDesc: body.customHeroDesc !== undefined ? (body.customHeroDesc?.slice(0, 300) || null) : existing.customHeroDesc,
      customIntro: body.customIntro !== undefined ? (body.customIntro?.slice(0, 1500) || null) : existing.customIntro,
    },
  });

  await logAdminAction("seo.intro.update", id, `${existing.entityType}:${existing.entityName}`);

  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  const { id } = await params;
  const numId = Number(id);
  if (!Number.isFinite(numId)) {
    return NextResponse.json({ ok: false, error: "ID inválido." }, { status: 400 });
  }

  let body: { csrf?: string } = {};
  try {
    body = await req.json();
  } catch { /* empty OK */ }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  const existing = await db.entityIntro.findUnique({
    where: { id: numId },
    select: { id: true, entityType: true, entityName: true },
  });
  if (!existing) {
    return NextResponse.json({ ok: false, error: "Intro no encontrado." }, { status: 404 });
  }

  await db.entityIntro.delete({ where: { id: numId } });

  await logAdminAction("seo.intro.delete", id, `${existing.entityType}:${existing.entityName}`);

  return NextResponse.json({ ok: true });
}
