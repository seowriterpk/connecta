import { NextRequest, NextResponse } from "next/server";
import { checkAdminApi, checkCsrfApi, logAdminAction } from "@/lib/admin-guard";
import { db } from "@/lib/db";
import { generateSlug, makeUniqueSlug } from "@/lib/slug";

export const dynamic = "force-dynamic";

interface RouteParams {
  params: Promise<{ id: string }>;
}

type UgcAction = "approve" | "reject" | "spam";

const ACTION_TO_STATUS: Record<UgcAction, string> = {
  approve: "approved",
  reject: "rejected",
  spam: "spam",
};

export async function POST(req: NextRequest, { params }: RouteParams) {
  const authErr = await checkAdminApi();
  if (authErr) return authErr;

  const { id } = await params;

  let body: { action?: UgcAction; csrf?: string } = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { ok: false, error: "Cuerpo inválido." },
      { status: 400 }
    );
  }

  const csrfErr = await checkCsrfApi(body.csrf);
  if (csrfErr) return csrfErr;

  if (!body.action || !ACTION_TO_STATUS[body.action]) {
    return NextResponse.json(
      { ok: false, error: "Acción no válida." },
      { status: 400 }
    );
  }

  const sub = await db.ugcSubmission.findUnique({ where: { id } });
  if (!sub) {
    return NextResponse.json(
      { ok: false, error: "Envío no encontrado." },
      { status: 404 }
    );
  }

  const newStatus = ACTION_TO_STATUS[body.action];
  const now = new Date();

  // For "approve" — promote the submission to a live group (status=live)
  let publishedGroupId: string | null = null;
  let publishedSlug: string | null = null;

  if (body.action === "approve") {
    // Resolve category + country
    let categoryId = sub.categoryId;
    let categoryName = sub.categoryNameSnapshot;
    let countryName = sub.country;

    if (!categoryId) {
      // Try to look up by name
      const cat = await db.category.findFirst({
        where: { name: sub.categoryNameSnapshot },
        select: { id: true, name: true },
      });
      if (!cat) {
        return NextResponse.json(
          { ok: false, error: "Categoría no resuelta. Edita el envío antes de aprobar." },
          { status: 400 }
        );
      }
      categoryId = cat.id;
      categoryName = cat.name;
    }
    const country = await db.country.findFirst({
      where: { name: sub.country },
      select: { id: true, name: true },
    });
    if (!country) {
      return NextResponse.json(
        { ok: false, error: "País no válido. Edita el envío antes de aprobar." },
        { status: 400 }
      );
    }
    countryName = country.name;

    // Generate unique slug
    const groupName = sub.editedGroupName || sub.fetchedGroupName;
    if (!groupName) {
      return NextResponse.json(
        { ok: false, error: "El envío no tiene nombre." },
        { status: 400 }
      );
    }
    const baseSlug = generateSlug(groupName);
    const existingOwner = await db.group.findUnique({
      where: { slug: baseSlug },
      select: { id: true },
    });
    const finalSlug =
      !existingOwner
        ? baseSlug
        : makeUniqueSlug(baseSlug, (s) => false); // fallback (will append number)

    // Parse tags/keywords JSON
    let tags: string[] = [];
    let keywords: string[] = [];
    try {
      tags = JSON.parse(sub.selectedTagsJson || "[]");
    } catch { /* ignore */ }
    try {
      keywords = JSON.parse(sub.keywordsJson || "[]");
    } catch { /* ignore */ }

    const newGroup = await db.group.create({
      data: {
        groupName,
        slug: finalSlug,
        joinLink: sub.inviteUrl,
        description: "",
        category: categoryName,
        categoryId: categoryId,
        country: countryName,
        countryId: country.id,
        city: sub.city || null,
        keywords: JSON.stringify(keywords),
        tags: JSON.stringify(tags),
        profileImage: sub.finalImageUrl || sub.fetchedImageUrl || null,
        language: sub.detectedLanguage || "Espanol",
        status: "live",
        linkStatus: "active",
        isAdult: sub.isAdult,
        submitSource: "ugc",
        ugcSubmissionId: sub.id,
        ugcContributorId: sub.contributorId ?? null,
      },
    });

    publishedGroupId = newGroup.id;
    publishedSlug = newGroup.slug;

    // Bump contributor stats
    if (sub.contributorId) {
      await db.ugcContributor.update({
        where: { id: sub.contributorId },
        data: {
          publishedCount: { increment: 1 },
          reputationScore: { increment: 5 },
          lastSubmissionAt: now,
        },
      });
    }
  } else if (body.action === "reject") {
    if (sub.contributorId) {
      await db.ugcContributor.update({
        where: { id: sub.contributorId },
        data: { rejectedCount: { increment: 1 } },
      });
    }
  }

  // Update submission status
  await db.ugcSubmission.update({
    where: { id },
    data: {
      status: newStatus,
      reviewedAt: now,
      publishedAt: body.action === "approve" ? now : null,
      publishedGroupId,
    },
  });

  await logAdminAction(
    `ugc.${body.action}`,
    id,
    sub.editedGroupName || sub.fetchedGroupName || sub.submissionUid
  );

  return NextResponse.json({
    ok: true,
    status: newStatus,
    publishedGroupId,
    publishedSlug,
  });
}
