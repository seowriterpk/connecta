/**
 * Duplicate Detection (invite-code based)
 * Based on Groupizo VIP Logic SYSTEM 9.
 *
 * Extracts invite code, searches groups + ugc_submissions using LIKE.
 */

import { db } from "./db";
import { extractInviteCode } from "./whatsapp-validator";

export interface DuplicateResult {
  isDuplicate: boolean;
  duplicateGroupId: string | null;
}

export async function detectDuplicate(inviteUrl: string): Promise<DuplicateResult> {
  const code = extractInviteCode(inviteUrl);
  if (!code) return { isDuplicate: false, duplicateGroupId: null };

  // Check groups table (LIKE %code%)
  const inGroups = await db.group.findFirst({
    where: { joinLink: { contains: code } },
    select: { id: true },
  });
  if (inGroups) {
    return { isDuplicate: true, duplicateGroupId: inGroups.id };
  }

  // Check ugc_submissions table (pending, not rejected)
  const inSubmissions = await db.ugcSubmission.findFirst({
    where: {
      inviteCode: code,
      status: { notIn: ["rejected", "spam", "deleted"] },
    },
    select: { publishedGroupId: true },
  });
  if (inSubmissions?.publishedGroupId) {
    return { isDuplicate: true, duplicateGroupId: inSubmissions.publishedGroupId };
  }

  return { isDuplicate: false, duplicateGroupId: null };
}
