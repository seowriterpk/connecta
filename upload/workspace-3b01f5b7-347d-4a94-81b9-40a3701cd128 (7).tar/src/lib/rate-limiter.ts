/**
 * Rate Limiter — Anti-Spam Submission Control
 * Based on Groupizo VIP Logic SYSTEM 5.
 *
 * Three-layer fingerprinting: IP + device token + UA hash.
 * Limits: 10/device/day, 30/IP/day, 1-hour block after limit hit.
 */

import { db } from "./db";
import crypto from "crypto";

export function hashValue(value: string): string {
  return crypto.createHash("sha256").update(value).digest("hex");
}

export function getClientIp(req: { headers: Record<string, string | string[] | undefined>; ip?: string }): string {
  const xff = req.headers["x-forwarded-for"];
  if (typeof xff === "string") return xff.split(",")[0].trim();
  if (Array.isArray(xff) && xff.length > 0) return xff[0].trim();
  return req.ip ?? "127.0.0.1";
}

interface RateCheckResult {
  allowed: boolean;
  remaining: number;
  blockedUntil: Date | null;
}

export async function checkRateLimit(
  rateKey: string,
  action: string,
  maxAllowed: number,
  windowSeconds: number
): Promise<RateCheckResult> {
  const existing = await db.rateLimit.findUnique({
    where: { rateKey_action: { rateKey, action } },
  });

  if (!existing) {
    return { allowed: true, remaining: maxAllowed, blockedUntil: null };
  }

  // Check block
  if (existing.blockedUntil && existing.blockedUntil > new Date()) {
    return { allowed: false, remaining: 0, blockedUntil: existing.blockedUntil };
  }

  // Check window expiry
  const windowMs = windowSeconds * 1000;
  const elapsed = Date.now() - existing.lastAttemptAt.getTime();
  if (elapsed > windowMs) {
    // Window expired → reset
    return { allowed: true, remaining: maxAllowed, blockedUntil: null };
  }

  // Check count
  if (existing.attempts >= maxAllowed) {
    const blockedUntil = new Date(Date.now() + 3600 * 1000); // 1 hour block
    await db.rateLimit.update({
      where: { id: existing.id },
      data: { blockedUntil },
    });
    return { allowed: false, remaining: 0, blockedUntil };
  }

  return { allowed: true, remaining: maxAllowed - existing.attempts, blockedUntil: null };
}

export async function hitRateLimit(
  rateKey: string,
  action: string
): Promise<void> {
  const existing = await db.rateLimit.findUnique({
    where: { rateKey_action: { rateKey, action } },
  });

  if (existing) {
    await db.rateLimit.update({
      where: { id: existing.id },
      data: {
        attempts: { increment: 1 },
        lastAttemptAt: new Date(),
      },
    });
  } else {
    await db.rateLimit.create({
      data: { rateKey, action, attempts: 1, lastAttemptAt: new Date() },
    });
  }
}

export async function checkUgcRateLimits(ip: string, deviceToken: string): Promise<{ allowed: boolean; reason?: string }> {
  const ipHash = hashValue(ip);
  const deviceHash = hashValue(deviceToken);

  // Device limit: 10/day
  const deviceCheck = await checkRateLimit(`submit_device:${deviceHash}`, "ugc_submit", 10, 86400);
  if (!deviceCheck.allowed) {
    return { allowed: false, reason: "Límite de envíos por dispositivo alcanzado (10/día)." };
  }

  // IP limit: 30/day
  const ipCheck = await checkRateLimit(`submit_ip:${ipHash}`, "ugc_submit", 30, 86400);
  if (!ipCheck.allowed) {
    return { allowed: false, reason: "Límite de envíos por IP alcanzado (30/día)." };
  }

  return { allowed: true };
}
