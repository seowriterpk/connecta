// ConectaGrupos — acceso a datos (server-side)
import { db } from "@/lib/db";
import { generateSlug, makeUniqueSlug } from "@/lib/slug";
import { computeDisplayedMembers } from "@/lib/members";
import type {
  CategoryDTO,
  CountryDTO,
  GroupDTO,
  GroupStatus,
  GroupsQuery,
  StatsDTO,
} from "@/lib/types";

function parseTags(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v.map(String) : [];
  } catch {
    return [];
  }
}

function toGroupDTO(g: any): GroupDTO {
  return {
    id: g.id,
    title: g.groupName ?? g.title,
    slug: g.slug,
    description: g.description,
    inviteLink: g.joinLink ?? g.inviteLink,
    imageUrl: g.profileImage ?? g.imageUrl ?? null,
    categoryId: g.categoryId,
    countryId: g.countryId,
    members: computeDisplayedMembers(g.clicks ?? 0, g.joinCount ?? 0, g.id),
    isFeatured: g.popularityBadge === "featured",
    isVerified: g.linkStatus === "active",
    status: (g.status as GroupStatus) ?? "ACTIVE",
    tags: parseTags(g.tags),
    keywords: parseTags(g.keywords),
    views: g.views ?? 0,
    shares: g.shares ?? 0,
    clicks: g.clicks ?? 0,
    joinCount: g.joinCount ?? 0,
    contactName: g.contactName,
    city: g.city ?? null,
    language: g.language ?? "Espanol",
    isAdult: g.isAdult ?? false,
    linkStatus: g.linkStatus ?? "active",
    uploaderId: g.uploaderId ?? null,
    uploaderName: g.uploader?.name ?? null,
    uploaderSlug: g.uploader?.slug ?? null,
    createdAt: g.createdAt instanceof Date ? g.createdAt.toISOString() : String(g.createdAt),
    lastActiveAt: g.lastActiveAt instanceof Date ? g.lastActiveAt.toISOString() : (g.lastActiveAt ? String(g.lastActiveAt) : null),
    category: g.categoryRef
      ? {
          id: g.categoryRef.id,
          name: g.categoryRef.name,
          slug: g.categoryRef.slug,
          description: g.categoryRef.description,
          icon: g.categoryRef.icon,
          color: g.categoryRef.color,
          sortOrder: g.categoryRef.sortOrder,
          groupCount: 0,
        }
      : g.category
      ? {
          id: g.category.id,
          name: g.category.name,
          slug: g.category.slug,
          description: g.category.description,
          icon: g.category.icon,
          color: g.category.color,
          sortOrder: g.category.sortOrder,
          groupCount: 0,
        }
      : undefined,
    country: g.countryRef
      ? {
          id: g.countryRef.id,
          name: g.countryRef.name,
          code: g.countryRef.code,
          flag: g.countryRef.flag,
          region: g.countryRef.region,
          dialCode: g.countryRef.dialCode,
          groupCount: 0,
        }
      : g.country
      ? {
          id: g.country.id,
          name: g.country.name,
          code: g.country.code,
          flag: g.country.flag,
          region: g.country.region,
          dialCode: g.country.dialCode,
          groupCount: 0,
        }
      : undefined,
  };
}

export async function getCategories(): Promise<CategoryDTO[]> {
  const rows = await db.category.findMany({
    orderBy: { sortOrder: "asc" },
    include: { _count: { select: { groups: true } } },
  });
  return rows.map((c) => ({
    id: c.id,
    name: c.name,
    slug: c.slug,
    description: c.description,
    icon: c.icon,
    color: c.color,
    sortOrder: c.sortOrder,
    groupCount: c._count.groups,
    isAdult: c.isAdult,
    isActive: c.isActive,
  }));
}

export async function getCountries(): Promise<CountryDTO[]> {
  const rows = await db.country.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { groups: true } } },
  });
  return rows.map((c) => ({
    id: c.id,
    name: c.name,
    code: c.code,
    flag: c.flag,
    region: c.region,
    dialCode: c.dialCode,
    groupCount: c._count.groups,
  }));
}

export async function getStats(): Promise<StatsDTO> {
  const [groups, categories, countries, agg] = await Promise.all([
    db.group.count({ where: { status: "live" } }),
    db.category.count(),
    db.country.count(),
    db.group.aggregate({ _sum: { clicks: true }, where: { status: "live" } }),
  ]);
  const featured = await db.group.count({ where: { status: "live", popularityBadge: "featured" } });
  return {
    groups,
    categories,
    countries,
    members: agg._sum.clicks ?? 0,
    featured,
  };
}

export async function getGroups(query: GroupsQuery = {}): Promise<GroupDTO[]> {
  const {
    search,
    categoryId,
    countryId,
    region,
    tag,
    featured,
    sort = "recientes",
    limit = 30,
    offset = 0,
    status = "live",
  } = query;

  const where: any = { status };
  if (categoryId) where.categoryId = categoryId;
  if (countryId) where.countryId = countryId;
  if (featured) where.popularityBadge = "featured";
  if (tag) {
    // tags stored as JSON string array: ["a","b"] -> match "tag" with quotes
    where.tags = { contains: `"${tag}"` };
  }
  if (search && search.trim().length > 0) {
    where.OR = [
      { title: { contains: search } },
      { description: { contains: search } },
    ];
  }
  if (region) {
    where.country = { region };
  }

  let orderBy: any = { createdAt: "desc" };
  if (sort === "miembros") orderBy = { clicks: "desc" };
  else if (sort === "populares") orderBy = { views: "desc" };
  else if (sort === "destacados") orderBy = [{ clicks: "desc" }, { clicks: "desc" }];

  const rows = await db.group.findMany({
    where,
    orderBy,
    take: Math.min(Math.max(limit, 1), 60),
    skip: Math.max(offset, 0),
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return rows.map(toGroupDTO);
}

export async function getGroupById(id: string): Promise<GroupDTO | null> {
  const g = await db.group.findUnique({
    where: { id },
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return g ? toGroupDTO(g) : null;
}

export async function incrementViews(id: string): Promise<void> {
  try {
    await db.group.update({ where: { id }, data: { views: { increment: 1 } } });
  } catch {
    /* ignore */
  }
}

export async function submitGroup(payload: {
  title: string;
  description: string;
  inviteLink: string;
  imageUrl?: string;
  categoryId: string;
  countryId: string;
  city?: string;
  contactName?: string;
  tags?: string[];
}): Promise<GroupDTO> {
  // Generate unique slug from title
  const baseSlug = generateSlug(payload.title);
  const existing = await db.group.findMany({
    where: { slug: { startsWith: baseSlug } },
    select: { slug: true },
  });
  const existingSet = new Set(existing.map((g) => g.slug));
  const slug = makeUniqueSlug(baseSlug, (s) => existingSet.has(s));

  const created = await db.group.create({
    data: {
      title: payload.title.trim(),
      slug,
      description: payload.description.trim(),
      inviteLink: payload.inviteLink.trim(),
      imageUrl: payload.imageUrl?.trim() || null,
      categoryId: payload.categoryId,
      countryId: payload.countryId,
      city: payload.city?.trim() || null,
      contactName: payload.contactName?.trim() || null,
      tags: JSON.stringify(payload.tags ?? []),
      status: "pending",
      popularityBadge: null,
      isVerified: false,
    },
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return toGroupDTO(created);
}

export async function getMetrics() {
  const [groups, categories, countries, pending, reports, newsletter, agg] = await Promise.all([
    db.group.count({ where: { status: "live" } }),
    db.category.count(),
    db.country.count(),
    db.group.count({ where: { status: "pending" } }),
    db.groupReport.count({ where: { status: "OPEN" } }),
    db.newsletter.count({ where: { status: "SUBSCRIBED" } }),
    db.group.aggregate({ _sum: { clicks: true }, where: { status: "live" } }),
  ]);

  // Groups per region + top countries (computed in JS)
  const activeGroups = await db.group.findMany({
    where: { status: "live" },
    select: { id: true, countryId: true, countryRef: { select: { name: true, flag: true, region: true } } },
  });
  const regionMap = new Map<string, number>();
  const countryMap = new Map<string, { name: string; flag: string; count: number }>();
  for (const g of activeGroups) {
    if (!g.countryRef) continue;
    regionMap.set(g.countryRef.region, (regionMap.get(g.countryRef.region) ?? 0) + 1);
    const key = g.countryId;
    const existing = countryMap.get(key);
    if (existing) existing.count += 1;
    else countryMap.set(key, { name: g.countryRef.name, flag: g.countryRef.flag, count: 1 });
  }
  const regions = [...regionMap.entries()]
    .map(([region, count]) => ({ region, count }))
    .sort((a, b) => b.count - a.count);
  const topCountries = [...countryMap.values()]
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  const featured = await db.group.count({ where: { status: "live", popularityBadge: "featured" } });

  return {
    groups,
    categories,
    countries,
    pending,
    reports,
    newsletter,
    featured,
    members: agg._sum.clicks ?? 0,
    regions,
    topCountries,
  };
}

export async function getGroupOfTheDay(): Promise<GroupDTO | null> {
  const rows = await db.group.findMany({
    where: { status: "live", popularityBadge: "featured" },
    orderBy: [{ clicks: "desc" }],
    take: 60,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  if (rows.length === 0) {
    const fallback = await db.group.findFirst({
      where: { status: "live" },
      orderBy: { views: "desc" },
      include: { categoryRef: true, countryRef: true, uploader: true },
    });
    return fallback ? toGroupDTO(fallback) : null;
  }
  // Deterministic daily rotation based on day-of-year
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const diff = now.getTime() - start.getTime();
  const dayOfYear = Math.floor(diff / 86400000);
  const pick = rows[dayOfYear % rows.length];
  return toGroupDTO(pick);
}

export async function getRelatedGroups(
  id: string,
  categoryId: string,
  limit = 4
): Promise<GroupDTO[]> {
  const rows = await db.group.findMany({
    where: {
      status: "live",
      id: { not: id },
      categoryId,
    },
    orderBy: [{ clicks: "desc" }, { clicks: "desc" }],
    take: limit,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return rows.map(toGroupDTO);
}

export async function getTrending(limit = 6): Promise<GroupDTO[]> {
  const rows = await db.group.findMany({
    where: { status: "live" },
    orderBy: [{ views: "desc" }, { clicks: "desc" }],
    take: limit,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return rows.map(toGroupDTO);
}

export async function getPopularTags(limit = 14): Promise<{ tag: string; count: number }[]> {
  const rows = await db.group.findMany({
    where: { status: "live" },
    select: { tags: true },
  });
  const counts = new Map<string, number>();
  for (const r of rows) {
    for (const t of parseTags(r.tags)) {
      counts.set(t, (counts.get(t) ?? 0) + 1);
    }
  }
  return [...counts.entries()]
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

export async function createReport(input: {
  groupId: string;
  reason: string;
  details?: string;
  contact?: string;
}): Promise<{ id: string }> {
  const created = await db.groupReport.create({
    data: {
      groupId: input.groupId,
      reporterIp: "0.0.0.0", // Will be overridden by API route if IP is available
      reason: input.reason,
      status: "OPEN",
    },
    select: { id: true },
  });
  return created;
}

export async function subscribeNewsletter(email: string, source = "footer"): Promise<{ id: string; existed: boolean }> {
  const existing = await db.newsletter.findUnique({ where: { email } });
  if (existing) {
    if (existing.status === "UNSUBSCRIBED") {
      await db.newsletter.update({ where: { email }, data: { status: "SUBSCRIBED", source } });
    }
    return { id: existing.id, existed: true };
  }
  const created = await db.newsletter.create({
    data: { email, source, status: "SUBSCRIBED" },
    select: { id: true },
  });
  return { id: created.id, existed: false };
}

export async function getGroupsCount(query: Omit<GroupsQuery, "sort" | "limit" | "offset"> = {}): Promise<number> {
  const { search, categoryId, countryId, region, tag, featured, status = "live" } = query;
  const where: any = { status };
  if (categoryId) where.categoryId = categoryId;
  if (countryId) where.countryId = countryId;
  if (featured) where.popularityBadge = "featured";
  if (tag) where.tags = { contains: `"${tag}"` };
  if (search && search.trim().length > 0) {
    where.OR = [
      { title: { contains: search } },
      { description: { contains: search } },
    ];
  }
  if (region) where.country = { region };
  return db.group.count({ where });
}

export async function getRandomGroup(): Promise<GroupDTO | null> {
  const total = await db.group.count({ where: { status: "live" } });
  if (total === 0) return null;
  const skip = Math.floor(Math.random() * total);
  const g = await db.group.findFirst({
    where: { status: "live" },
    skip,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return g ? toGroupDTO(g) : null;
}

export async function getRecentGroups(limit = 6): Promise<GroupDTO[]> {
  const rows = await db.group.findMany({
    where: { status: "live" },
    orderBy: { createdAt: "desc" },
    take: limit,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return rows.map(toGroupDTO);
}

export async function getGroupRatingStats(groupId: string): Promise<{ avg: number; count: number }> {
  const rows = await db.groupReview.findMany({
    where: { groupId },
    select: { rating: true },
  });
  if (rows.length === 0) return { avg: 0, count: 0 };
  const sum = rows.reduce((a, r) => a + r.rating, 0);
  return { avg: Math.round((sum / rows.length) * 10) / 10, count: rows.length };
}

export async function submitRating(
  groupId: string,
  rating: number,
  ipHash: string
): Promise<{ avg: number; count: number; updated: boolean }> {
  const clamped = Math.max(1, Math.min(5, Math.round(rating)));
  const existing = await db.groupReview.findUnique({
    where: { groupId_ipHash: { groupId, ipHash } },
  });
  if (existing) {
    await db.groupReview.update({
      where: { id: existing.id },
      data: { rating: clamped },
    });
  } else {
    await db.groupReview.create({
      data: { groupId, rating: clamped, ipHash },
    });
  }
  const stats = await getGroupRatingStats(groupId);
  return { ...stats, updated: !!existing };
}

export async function getTopRatedGroups(limit = 6): Promise<GroupDTO[]> {
  // Get groups that have at least 1 rating, ordered by avg rating then count
  const rated = await db.groupReview.groupBy({
    by: ["groupId"],
    _avg: { rating: true },
    _count: { rating: true },
    orderBy: { _count: { rating: "desc" } },
    take: 50,
  });
  if (rated.length === 0) {
    // Fallback: none rated yet, return empty
    return [];
  }
  const ids = rated
    .sort((a, b) => {
      const aAvg = a._avg.rating ?? 0;
      const bAvg = b._avg.rating ?? 0;
      if (bAvg !== aAvg) return bAvg - aAvg;
      return b._count.rating - a._count.rating;
    })
    .slice(0, limit)
    .map((r) => r.groupId);
  const rows = await db.group.findMany({
    where: { id: { in: ids }, status: "live" },
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  // Preserve order by ids
  return ids.map((id) => rows.find((r) => r.id === id)).filter(Boolean).map(toGroupDTO);
}

export async function getRatingsBatch(groupIds: string[]): Promise<Record<string, { avg: number; count: number }>> {
  if (groupIds.length === 0) return {};
  const rows = await db.groupReview.groupBy({
    by: ["groupId"],
    _avg: { rating: true },
    _count: { rating: true },
    where: { groupId: { in: groupIds } },
  });
  const map: Record<string, { avg: number; count: number }> = {};
  for (const r of rows) {
    const avg = r._avg.rating ?? 0;
    map[r.groupId] = {
      avg: Math.round(avg * 10) / 10,
      count: r._count.rating,
    };
  }
  return map;
}

export async function incrementShares(id: string): Promise<void> {
  try {
    await db.group.update({ where: { id }, data: { shares: { increment: 1 } } });
  } catch {
    /* ignore */
  }
}

export async function touchGroupActivity(id: string): Promise<void> {
  try {
    await db.group.update({ where: { id }, data: { lastActiveAt: new Date() } });
  } catch {
    /* ignore */
  }
}

export async function getMostSharedGroups(limit = 6): Promise<GroupDTO[]> {
  const rows = await db.group.findMany({
    where: { status: "live", shares: { gt: 0 } },
    orderBy: { shares: "desc" },
    take: limit,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return rows.map(toGroupDTO);
}

// ---------------------------------------------------------------------------
// Dedicated page data functions
// ---------------------------------------------------------------------------

export async function getCategoryBySlug(slug: string) {
  const c = await db.category.findUnique({ where: { slug } });
  if (!c) return null;
  const count = await db.group.count({ where: { categoryId: c.id, status: "live" } });
  return {
    id: c.id,
    name: c.name,
    slug: c.slug,
    description: c.description,
    icon: c.icon,
    color: c.color,
    sortOrder: c.sortOrder,
    groupCount: count,
  };
}

export async function getCountryByCode(code: string) {
  const c = await db.country.findUnique({ where: { code: code.toLowerCase() } });
  if (!c) return null;
  const count = await db.group.count({ where: { countryId: c.id, status: "live" } });
  return {
    id: c.id,
    name: c.name,
    code: c.code,
    flag: c.flag,
    region: c.region,
    dialCode: c.dialCode,
    groupCount: count,
  };
}

export async function getGroupsByCategorySlug(slug: string, limit = 60): Promise<GroupDTO[]> {
  const cat = await db.category.findUnique({ where: { slug } });
  if (!cat) return [];
  return getGroups({ categoryId: cat.id, limit, sort: "destacados" });
}

export async function getGroupsByCountryCode(code: string, limit = 60): Promise<GroupDTO[]> {
  const country = await db.country.findUnique({ where: { code: code.toLowerCase() } });
  if (!country) return [];
  return getGroups({ countryId: country.id, limit, sort: "destacados" });
}

export function citySlug(city: string): string {
  return city
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export async function getAllCities(): Promise<{ city: string; slug: string; groupCount: number; countryCode: string; countryFlag: string }[]> {
  const rows = await db.group.findMany({
    where: { status: "live", city: { not: null } },
    select: { city: true, countryRef: { select: { code: true, flag: true } } },
  });
  const map = new Map<string, { city: string; groupCount: number; countryCode: string; countryFlag: string }>();
  for (const r of rows) {
    if (!r.city) continue;
    const existing = map.get(r.city);
    if (existing) {
      existing.groupCount += 1;
    } else {
      map.set(r.city, { city: r.city, groupCount: 1, countryCode: r.countryRef?.code ?? "", countryFlag: r.countryRef?.flag ?? "🏳️" });
    }
  }
  return [...map.values()]
    .map((c) => ({ ...c, slug: citySlug(c.city) }))
    .sort((a, b) => b.groupCount - a.groupCount);
}

export async function getCityBySlug(slug: string) {
  const cities = await getAllCities();
  return cities.find((c) => c.slug === slug) ?? null;
}

export async function getGroupsByCity(city: string, limit = 60): Promise<GroupDTO[]> {
  const rows = await db.group.findMany({
    where: { status: "live", city: city },
    orderBy: [{ clicks: "desc" }, { clicks: "desc" }],
    take: limit,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return rows.map(toGroupDTO);
}

export async function getAllGroupIds(): Promise<string[]> {
  const rows = await db.group.findMany({ where: { status: "live" }, select: { id: true } });
  return rows.map((r) => r.id);
}

export async function getAllCategorySlugs(): Promise<string[]> {
  const rows = await db.category.findMany({ select: { slug: true } });
  return rows.map((r) => r.slug);
}

export async function getAllCountryCodes(): Promise<string[]> {
  const rows = await db.country.findMany({ select: { code: true } });
  return rows.map((r) => r.code);
}

// ---------------------------------------------------------------------------
// Slug-based + paginated data functions
// ---------------------------------------------------------------------------

const PAGE_SIZE = 120;

export async function getGroupBySlug(slug: string): Promise<GroupDTO | null> {
  const g = await db.group.findUnique({
    where: { slug },
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return g ? toGroupDTO(g) : null;
}

export interface PaginatedGroups {
  groups: GroupDTO[];
  total: number;
  page: number;
  totalPages: number;
  hasPrev: boolean;
  hasNext: boolean;
}

async function buildPaginated(
  where: any,
  orderBy: any,
  page: number
): Promise<PaginatedGroups> {
  const total = await db.group.count({ where });
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const skip = (safePage - 1) * PAGE_SIZE;
  const rows = await db.group.findMany({
    where,
    orderBy,
    take: PAGE_SIZE,
    skip,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return {
    groups: rows.map(toGroupDTO),
    total,
    page: safePage,
    totalPages,
    hasPrev: safePage > 1,
    hasNext: safePage < totalPages,
  };
}

export async function getGroupsByCategorySlugPaginated(slug: string, page: number) {
  const cat = await db.category.findUnique({ where: { slug } });
  if (!cat) return null;
  const result = await buildPaginated(
    { status: "live", categoryId: cat.id },
    [{ clicks: "desc" }, { clicks: "desc" }],
    page
  );
  return { category: cat, ...result };
}

export async function getGroupsByCountryCodePaginated(code: string, page: number) {
  const country = await db.country.findUnique({ where: { code: code.toLowerCase() } });
  if (!country) return null;
  const result = await buildPaginated(
    { status: "live", countryId: country.id },
    [{ clicks: "desc" }, { clicks: "desc" }],
    page
  );
  return { country, ...result };
}

export async function getGroupsByCityPaginated(city: string, page: number) {
  const result = await buildPaginated(
    { status: "live", city },
    [{ clicks: "desc" }, { clicks: "desc" }],
    page
  );
  return result;
}

/**
 * Get 30 related groups for a given group.
 * Priority: same city → same country → same category.
 * Returns up to 30 groups, excluding the current one.
 */
export async function getRelatedGroupsExtended(group: GroupDTO, limit = 30): Promise<GroupDTO[]> {
  const excludeId = group.id;

  // Try same city first
  if (group.city) {
    const byCity = await db.group.findMany({
      where: { status: "live", city: group.city, id: { not: excludeId } },
      orderBy: [{ clicks: "desc" }, { clicks: "desc" }],
      take: limit,
      include: { categoryRef: true, countryRef: true, uploader: true },
    });
    if (byCity.length >= limit) return byCity.map(toGroupDTO);

    // If not enough by city, supplement by country
    const remaining = limit - byCity.length;
    const cityIds = new Set(byCity.map((g) => g.id));
    const byCountry = await db.group.findMany({
      where: {
        status: "live",
        countryId: group.countryId,
        id: { notIn: [...cityIds, excludeId] },
      },
      orderBy: [{ clicks: "desc" }, { clicks: "desc" }],
      take: remaining,
      include: { categoryRef: true, countryRef: true, uploader: true },
    });
    const combined = [...byCity, ...byCountry];
    if (combined.length >= limit) return combined.slice(0, limit).map(toGroupDTO);

    // Supplement by category
    const remaining2 = limit - combined.length;
    const combinedIds = new Set(combined.map((g) => g.id));
    const byCategory = await db.group.findMany({
      where: {
        status: "live",
        categoryId: group.categoryId,
        id: { notIn: [...combinedIds, excludeId] },
      },
      orderBy: [{ clicks: "desc" }, { clicks: "desc" }],
      take: remaining2,
      include: { categoryRef: true, countryRef: true, uploader: true },
    });
    return [...combined, ...byCategory].slice(0, limit).map(toGroupDTO);
  }

  // No city: try same country
  const byCountry = await db.group.findMany({
    where: { status: "live", countryId: group.countryId, id: { not: excludeId } },
    orderBy: [{ clicks: "desc" }, { clicks: "desc" }],
    take: limit,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  if (byCountry.length >= limit) return byCountry.map(toGroupDTO);

  // Supplement by category
  const remaining = limit - byCountry.length;
  const countryIds = new Set(byCountry.map((g) => g.id));
  const byCategory = await db.group.findMany({
    where: {
      status: "live",
      categoryId: group.categoryId,
      id: { notIn: [...countryIds, excludeId] },
    },
    orderBy: [{ clicks: "desc" }, { clicks: "desc" }],
    take: remaining,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  let combined = [...byCountry, ...byCategory];
  if (combined.length < limit) {
    // Final fallback: any active groups (popular ones)
    const remaining2 = limit - combined.length;
    const combinedIds = new Set(combined.map((g) => g.id));
    const fallback = await db.group.findMany({
      where: {
        status: "live",
        id: { notIn: [...combinedIds, excludeId] },
      },
      orderBy: [{ clicks: "desc" }, { views: "desc" }, { clicks: "desc" }],
      take: remaining2,
      include: { categoryRef: true, countryRef: true, uploader: true },
    });
    combined = [...combined, ...fallback];
  }
  return combined.slice(0, limit).map(toGroupDTO);
}

export async function getAllGroupSlugs(): Promise<string[]> {
  const rows = await db.group.findMany({ where: { status: "live" }, select: { slug: true } });
  return rows.map((r) => r.slug);
}

export async function incrementClicks(id: string): Promise<void> {
  try {
    await db.group.update({ where: { id }, data: { clicks: { increment: 1 } } });
  } catch {
    /* ignore */
  }
}

// ---------------------------------------------------------------------------
// SEARCH — AND-words full-text search across groupName, description, tags, keywords
// ---------------------------------------------------------------------------

export interface SearchGroupsResult {
  groups: GroupDTO[];
  total: number;
}

function escapeSqlLike(value: string): string {
  // Escape characters that have meaning in SQLite LIKE.
  // Prisma `contains` does not normally need %/_ escapes for plain substring matches
  // (it wraps the value in %value%), but we still sanitize to avoid surprising behaviour.
  return value.replace(/[\\%_]/g, (m) => `\\${m}`);
}

/**
 * Full-text search across groupName, description, tags and keywords.
 * AND-logic: every word in `q` must match (in any of the four fields).
 * Case-insensitive via lowercased values (SQLite does not support Prisma's `mode: insensitive`).
 * Returns up to `limit` results ordered by relevance (clicks + views).
 */
export async function searchGroups(q: string, limit = 48): Promise<SearchGroupsResult> {
  const raw = (q ?? "").trim();
  if (!raw) return { groups: [], total: 0 };

  // Split on whitespace, filter empties, lowercase, dedupe.
  const words = Array.from(new Set(raw.split(/\s+/).map((w) => w.toLowerCase()).filter(Boolean)));
  if (words.length === 0) return { groups: [], total: 0 };

  // Build the AND filter: for each word, the group must contain it in at least one of the
  // four text fields. We achieve this with an AND of OR groups.
  const andClauses = words.map((word) => {
    const escWord = escapeSqlLike(word);
    return {
      OR: [
        { groupName: { contains: escWord } },
        { description: { contains: escWord } },
        { tags: { contains: escWord } },
        { keywords: { contains: escWord } },
      ],
    };
  });

  const where = {
    status: "live" as const,
    isAdult: false,
    AND: andClauses,
  };

  const [rows, total] = await Promise.all([
    db.group.findMany({
      where,
      orderBy: [{ clicks: "desc" }, { views: "desc" }, { createdAt: "desc" }],
      take: Math.min(Math.max(limit, 1), 100),
      include: { categoryRef: true, countryRef: true, uploader: true },
    }),
    db.group.count({ where }),
  ]);

  return { groups: rows.map(toGroupDTO), total };
}

// ---------------------------------------------------------------------------
// TAG PAGES — slug -> tag-name reverse lookup + paginated groups
// ---------------------------------------------------------------------------

/**
 * Reverse-lookup the human-readable tag name from its slug.
 * Strategy: scan every live non-adult group's tags JSON, slugify each tag, and
 * return the first tag whose slug matches `slug`. Returns null if not found.
 */
export async function getTagBySlug(
  slug: string
): Promise<{ name: string; slug: string; count: number } | null> {
  const rows = await db.group.findMany({
    where: { status: "live", isAdult: false },
    select: { tags: true },
  });
  const counts = new Map<string, number>();
  for (const r of rows) {
    for (const t of parseTags(r.tags)) {
      if (citySlug(t) === slug) {
        counts.set(t, (counts.get(t) ?? 0) + 1);
      }
    }
  }
  if (counts.size === 0) return null;
  // Pick the most common variant of the tag (case differences can produce duplicates).
  const [name, count] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
  return { name, slug: citySlug(name), count };
}

/**
 * Paginated groups that contain `tagName` in their tags JSON array.
 * 48 per page (per task spec). Ordered by clicks desc then views desc.
 */
export async function getGroupsByTagPaginated(
  tagName: string,
  page: number
): Promise<PaginatedGroups> {
  const PAGE = 48;
  const where = {
    status: "live" as const,
    isAdult: false,
    tags: { contains: `"${tagName}"` },
  };
  const total = await db.group.count({ where });
  const totalPages = Math.max(1, Math.ceil(total / PAGE));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const skip = (safePage - 1) * PAGE;
  const rows = await db.group.findMany({
    where,
    orderBy: [{ clicks: "desc" }, { views: "desc" }, { createdAt: "desc" }],
    take: PAGE,
    skip,
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return {
    groups: rows.map(toGroupDTO),
    total,
    page: safePage,
    totalPages,
    hasPrev: safePage > 1,
    hasNext: safePage < totalPages,
  };
}

/**
 * Related tags: top N tags co-occurring with the current tag (excluding itself).
 */
export async function getRelatedTags(tagName: string, limit = 16): Promise<{ tag: string; count: number }[]> {
  const rows = await db.group.findMany({
    where: { status: "live", isAdult: false, tags: { contains: `"${tagName}"` } },
    select: { tags: true },
  });
  const target = tagName.toLowerCase();
  const counts = new Map<string, number>();
  for (const r of rows) {
    for (const t of parseTags(r.tags)) {
      if (t.toLowerCase() === target) continue;
      counts.set(t, (counts.get(t) ?? 0) + 1);
    }
  }
  return [...counts.entries()]
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

// ---------------------------------------------------------------------------
// UPLOADER (author) PAGES
// ---------------------------------------------------------------------------

export interface UploaderDTO {
  id: string;
  name: string;
  slug: string;
  jobTitle: string;
  description: string | null;
  facebookUrl: string | null;
  twitterUrl: string | null;
  linkedinUrl: string | null;
  websiteUrl: string | null;
  imageUrl: string | null;
  createdAt: Date;
  lastActiveAt: Date;
}

export async function getUploaderBySlug(slug: string): Promise<UploaderDTO | null> {
  const u = await db.uploader.findUnique({ where: { slug } });
  if (!u) return null;
  return {
    id: u.id,
    name: u.name,
    slug: u.slug,
    jobTitle: u.jobTitle,
    description: u.description,
    facebookUrl: u.facebookUrl,
    twitterUrl: u.twitterUrl,
    linkedinUrl: u.linkedinUrl,
    websiteUrl: u.websiteUrl,
    imageUrl: u.imageUrl,
    createdAt: u.createdAt,
    lastActiveAt: u.lastActiveAt,
  };
}

export async function getAllUploaderSlugs(): Promise<string[]> {
  const rows = await db.uploader.findMany({ select: { slug: true } });
  return rows.map((r) => r.slug);
}

/**
 * Get all live non-adult groups published by an uploader.
 * Ordered by clicks desc, then views desc.
 */
export async function getGroupsByUploader(uploaderId: string, limit = 60): Promise<GroupDTO[]> {
  const rows = await db.group.findMany({
    where: { status: "live", isAdult: false, uploaderId },
    orderBy: [{ clicks: "desc" }, { views: "desc" }, { createdAt: "desc" }],
    take: Math.min(Math.max(limit, 1), 100),
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return rows.map(toGroupDTO);
}

/**
 * Distinct category names covered by an uploader (for the stats card).
 */
export async function getUploaderCategories(uploaderId: string): Promise<{ name: string; slug: string; count: number }[]> {
  const rows = await db.group.findMany({
    where: { status: "live", isAdult: false, uploaderId },
    select: { categoryRef: { select: { name: true, slug: true } } },
  });
  const map = new Map<string, { name: string; slug: string; count: number }>();
  for (const r of rows) {
    const c = r.categoryRef;
    if (!c) continue;
    const existing = map.get(c.slug);
    if (existing) existing.count += 1;
    else map.set(c.slug, { name: c.name, slug: c.slug, count: 1 });
  }
  return [...map.values()].sort((a, b) => b.count - a.count);
}

// ---------------------------------------------------------------------------
// RSS FEED — newest live non-adult groups
// ---------------------------------------------------------------------------

export async function getNewestGroupsForRss(limit = 50): Promise<GroupDTO[]> {
  const rows = await db.group.findMany({
    where: { status: "live", isAdult: false },
    orderBy: [{ createdAt: "desc" }],
    take: Math.min(Math.max(limit, 1), 100),
    include: { categoryRef: true, countryRef: true, uploader: true },
  });
  return rows.map(toGroupDTO);
}
