/**
 * Related Groups Engine (Smart Selection)
 * Based on Groupizo VIP Logic SYSTEM 14.
 *
 * Returns 10 related groups: 4 newest + 4 fewest clicks + 2 random.
 * Priority: same category AND country, with fallbacks.
 */

import { db } from "./db";
import type { GroupDTO } from "./types";
import { computeDisplayedMembers } from "./members";

function toDTO(g: any): GroupDTO {
  return {
    id: g.id,
    title: g.groupName,
    slug: g.slug,
    description: g.description,
    inviteLink: g.joinLink,
    imageUrl: g.profileImage ?? null,
    categoryId: g.categoryId,
    countryId: g.countryId,
    members: computeDisplayedMembers(g.clicks ?? 0, g.views ?? 0, g.id),
    isFeatured: g.popularityBadge === "featured",
    isVerified: g.linkStatus === "active",
    status: g.status as any,
    tags: JSON.parse(g.tags || "[]"),
    keywords: JSON.parse(g.keywords || "[]"),
    views: g.views ?? 0,
    shares: g.shares ?? 0,
    clicks: g.clicks ?? 0,
    joinCount: g.joinCount ?? 0,
    contactName: null,
    city: g.city,
    language: g.language ?? "Espanol",
    isAdult: g.isAdult ?? false,
    linkStatus: g.linkStatus ?? "active",
    uploaderId: g.uploaderId ?? null,
    uploaderName: null,
    uploaderSlug: null,
    createdAt: g.createdAt instanceof Date ? g.createdAt.toISOString() : String(g.createdAt),
    lastActiveAt: g.lastActiveAt instanceof Date ? g.lastActiveAt.toISOString() : null,
    category: g.categoryRef
      ? { id: g.categoryRef.id, name: g.categoryRef.name, slug: g.categoryRef.slug, description: g.categoryRef.description, icon: g.categoryRef.icon, color: g.categoryRef.color, sortOrder: g.categoryRef.sortOrder, groupCount: 0 }
      : undefined,
    country: g.countryRef
      ? { id: g.countryRef.id, name: g.countryRef.name, code: g.countryRef.code, flag: g.countryRef.flag, region: g.countryRef.region, dialCode: g.countryRef.dialCode, groupCount: 0 }
      : undefined,
  };
}

function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export async function getRelatedGroups(
  currentGroupId: string,
  category: string,
  country: string,
  limit = 10
): Promise<any[]> {
  const usedIds = new Set<string>([currentGroupId]);

  const baseWhere = {
    status: "live" as const,
    linkStatus: "active" as const,
    isAdult: false,
  };

  // FETCH 1: 4 newest from same category AND country
  let newest = await db.group.findMany({
    where: { ...baseWhere, category, country, id: { notIn: [...usedIds] } },
    orderBy: { createdAt: "desc" },
    take: 4,
    include: { categoryRef: true, countryRef: true },
  });
  newest.forEach((g) => usedIds.add(g.id));

  // Fallback: if not enough, same category only (no country)
  if (newest.length < 4) {
    const fallback = await db.group.findMany({
      where: { ...baseWhere, category, id: { notIn: [...usedIds] } },
      orderBy: { createdAt: "desc" },
      take: 4 - newest.length,
      include: { categoryRef: true, countryRef: true },
    });
    newest = [...newest, ...fallback];
    fallback.forEach((g) => usedIds.add(g.id));
  }

  // FETCH 2: 4 with fewest clicks (exposure boost)
  let fewestClicks = await db.group.findMany({
    where: { ...baseWhere, category, country, id: { notIn: [...usedIds] } },
    orderBy: [{ clicks: "asc" }, { createdAt: "desc" }],
    take: 4,
    include: { categoryRef: true, countryRef: true },
  });
  fewestClicks.forEach((g) => usedIds.add(g.id));

  if (fewestClicks.length < 4) {
    const fallback = await db.group.findMany({
      where: { ...baseWhere, category, id: { notIn: [...usedIds] } },
      orderBy: [{ clicks: "asc" }, { createdAt: "desc" }],
      take: 4 - fewestClicks.length,
      include: { categoryRef: true, countryRef: true },
    });
    fewestClicks = [...fewestClicks, ...fallback];
    fallback.forEach((g) => usedIds.add(g.id));
  }

  // FETCH 3: 2 random
  let randomGroups = await db.group.findMany({
    where: { ...baseWhere, id: { notIn: [...usedIds] } },
    orderBy: { createdAt: "desc" },
    take: 20,
    include: { categoryRef: true, countryRef: true },
  });
  randomGroups = shuffle(randomGroups).slice(0, 2);

  // Merge and shuffle
  const all = [...newest, ...fewestClicks, ...randomGroups];
  return shuffle(all).slice(0, limit).map(toDTO);
}
