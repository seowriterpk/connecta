import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Configure Prisma with connection pool settings for MySQL
// pool_timeout: how long to wait for a connection from the pool
// connection_limit: max concurrent connections
const databaseUrl = new URL(process.env.DATABASE_URL || 'file:./dev.db')
// Add pool parameters for MySQL
if (databaseUrl.protocol === 'mysql:') {
  if (!databaseUrl.searchParams.has('connection_limit')) {
    databaseUrl.searchParams.set('connection_limit', '10')
  }
  if (!databaseUrl.searchParams.has('pool_timeout')) {
    databaseUrl.searchParams.set('pool_timeout', '15')
  }
  if (!databaseUrl.searchParams.has('connect_timeout')) {
    databaseUrl.searchParams.set('connect_timeout', '10')
  }
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'production' ? ['error'] : ['error', 'warn'],
    datasources: {
      db: {
        url: databaseUrl.toString(),
      },
    },
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
