# Task p6-city-page — City listing page

## File written
- `/home/z/my-project/src/app/ciudad/[slug]/page.tsx` (server component, `revalidate = 300`)

## What it does
- `generateMetadata({ params: Promise<{ slug: string }> })` → title `Grupos de WhatsApp en {city} | ConectaGrupos` (via `title: { absolute }` to bypass root layout `%s · ConectaGrupos` template), description, canonical, OG, Twitter, keywords.
- `CityPage`: `getCityBySlug(slug)` → `notFound()` if null. Parallel `getGroupsByCity(city.city, 60)` + `getCategories()` + `getCountries()`. `getRatingsBatch(groupIds)`.
- JSON-LD: CollectionPage (about → City, containedInPlace → Country, mainEntity → ItemList) + BreadcrumbList.
- Layout: SiteHeader → main (breadcrumb Inicio>Ciudades>{city} → header with flag/group-count/country badges → groups grid 1/2/3/4 cols → 4-paragraph SEO content → emerald CTA with SubmitDialog) → BackToTop.

## Verification
- `bun run lint` → 0 problems.
- `bunx tsc --noEmit` → 0 errors in ciudad page (pre-existing errors elsewhere, unrelated).
- `GET /ciudad/ciudad-de-mexico` → 200 (166KB, 4 group cards, title exact, all JSON-LD types present).
- `GET /ciudad/madrid` → 200 (155KB, 3 cards).
- `GET /ciudad/esta-ciudad-no-existe` → 404.

## Environment fix applied (not a page bug)
- Prisma error `Unknown argument 'city'` (HTTP 500) was caused by the running dev server's PrismaClient singleton (cached on globalThis in src/lib/db.ts) being created from a stale generated client that predates the Group.city field. Ran `bunx prisma generate` (updated client files) + restarted dev server via `setsid bash -c 'exec bun run dev'` so a fresh PrismaClient instance picks up the `city` field. No source files modified for this fix.

## Data note (pre-existing)
- Seed has city↔country mismatches (e.g. group with city "Ciudad de México" but countryId "es"). `getAllCities()` takes first group's flag → CDMX page shows 🇪🇸. Not fixed (out of task scope; page faithfully renders getCityBySlug output). Madrid page correctly shows 🇪🇸.

## Unresolved recommendations
- Fix seed city↔country consistency, OR enhance getAllCities() to pick mode country per city.
- Add generateStaticParams (getAllCities slugs) for build-time pre-render.
- Add /ciudad/[slug] routes to sitemap.ts.
- Add #ciudades section to home page (breadcrumb currently links "Ciudades" → /#paises).
- SubmitDialog could accept defaultCountryId/defaultCity for pre-selection on city pages.
