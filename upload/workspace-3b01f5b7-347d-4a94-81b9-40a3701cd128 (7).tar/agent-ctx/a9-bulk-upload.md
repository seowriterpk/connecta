# Task ID: a9-bulk-upload — Bulk Upload System (CSV + JSON builder)

**Agent:** subagent (fullstack — admin bulk upload feature)
**Date:** 2026-09-29
**Stack:** Next.js 16 App Router + Prisma (SQLite/MySQL) + shadcn/ui + TypeScript

---

## Summary

Built an end-to-end **bulk upload system** for the ConectaGrupos admin panel:
admins can either upload a CSV file or paste/edit a JSON array of groups, see a
validated preview table (per-row green/red with reasons), and import them into
either `groups_queue` (drip-feed cron target) or `groups` table with
`status="pending"`. All insertions are dedup-checked against existing
`join_link` values (DB-side) plus intra-batch slug/link uniqueness.

---

## Files Created

| File | Type | Purpose |
|---|---|---|
| `src/lib/bulk-import.ts` | server lib | CSV parser (`parseCSV`), row normalizer/validator (`normalizeRow`), DB-side batch validator (`validateGroupRows`), bulk inserter (`importGroups`), CSV template generator (`csvTemplate`). |
| `src/app/api/admin/bulk-upload/route.ts` | API POST | Auth + CSRF + body validation + bulk insert via `importGroups`. Returns `{ ok, imported, skipped, errors }`. |
| `src/components/admin/bulk-upload-form.tsx` | client component | Tabs (CSV / JSON), drag-and-drop CSV zone, JSON editor with live validation, column-mapping guide, preview table with per-row validation, target selector (queue/pending), import button, results panel, CSV template download. |
| `src/app/admin/bulk-upload/page.tsx` | server component | `checkAdmin`-guarded page that loads categories + countries banks, renders intro card + `<BulkUploadForm>` + workflow steps. |

## Files Modified

| File | Change |
|---|---|
| `src/app/admin/page.tsx` | Added `UploadCloud` icon import + new entry in `QUICK_ACTIONS` array pointing to `/admin/bulk-upload` ("Carga masiva", "Importa grupos desde CSV o JSON."). |

---

## Implementation Details

### 1. `src/lib/bulk-import.ts`

**`parseCSV(text)`** — RFC-4180-style CSV parser:
- Strips BOM, normalizes CRLF → LF.
- Handles quoted fields with embedded commas, newlines, and `""` escaped quotes.
- Returns `{ headers: string[], rows: Record<string, string>[] }`.
- Drops fully-empty trailing rows.

**`normalizeRow(raw)`** — pure (no DB) shape + URL validator. Throws Spanish
error messages on validation failure:
- `group_name` required (3–120 chars)
- `join_link` required, must match `^https?://(chat\.whatsapp\.com|wa\.me)/...`
- `description` required (≥ 20 chars, ≤ 2000)
- `category` required (string, existence checked elsewhere)
- `country` required (string, existence checked elsewhere)
- `city` optional
- `tags` / `keywords` parsed (comma or semicolon separator, dedup, max 10)
- `profile_image` optional (must be `http(s)://`)
- `is_adult` parsed via `parseBool` (1/true/yes/si/sí)
- Generates slug via existing `generateSlug()` from `src/lib/slug.ts`
- Strips Groupizo stopwords from tags (`whatsapp`, `grupo`, `enlace`, `gratis`,
  `activo`, `nuevo`, `ultimo`, `último`, `online`, `chat`, `unirse`).

**`validateGroupRows(rows)`** — full DB-aware validator that loads category,
country, and existing groups (slugs + join links) in a single
`Promise.all`. Checks:
- shape + URL (via `normalizeRow`)
- category exists in `category_bank` and is `isActive`
- if category is `isAdult` but row didn't declare adult, auto-flip
- country exists in `country_bank` (matches `name` or `nameEs`)
- slug uniqueness: against DB and within batch
- join_link uniqueness: against DB and within batch

**`importGroups(rows, options)`** — bulk inserter:
- Cap of 500 rows per call (defensive).
- Single fetch of all categories + countries + existing `joinLink`s up-front
  (cheap dedup check).
- For each row: look up categoryId + countryId by lowercased name, ensure slug
  uniqueness against DB (`ensureUniqueDbSlug` with `-2..-50` fallback then
  timestamp suffix), insert into either `groups_queue` or `groups` table.
- `groups` inserts use `status="pending"`, `linkStatus="active"`,
  `submitSource="staff"`, `lastValidatedAt=now`, `imageRefreshedAt` set only if
  `profileImage` provided.
- Errors per row are caught, logged, and the function continues to the next
  row. Returns `{ imported, skipped, errors }`.

**`csvTemplate()`** — returns a CSV string with header + 2 example rows
(Cocina Mexicana Tradicional + Programadores Latam) using the 10 expected
column names.

**Type exports**: `RawGroupRow`, `ValidatedGroupRow`, `NormalizedGroup`,
`ImportResult`, `ImportTarget`.

### 2. `src/app/api/admin/bulk-upload/route.ts`

- `dynamic = "force-dynamic"`.
- `checkAdminApi()` → 401 if no admin session.
- Parses JSON body, `checkCsrfApi(body.csrf)` → 403 if invalid.
- Validates `groups` is a non-empty array (≤ 500).
- Picks `target` from `"queue" | "pending"` (defaults to `pending`).
- Loops rows: calls `normalizeRow(row)` (throws on shape error). Pushes
  valid rows to a list, collects errors with `{ rowIndex, rowName, reason }`.
- Calls `importGroups(validRows, { target })`.
- Merges pre-validation errors with insert errors.
- Logs to `admin_activity_log` via `logAdminAction()` with a summary like
  `"bulk-upload.import (pending)"` + `"12 importados / 3 omitidos · csv"`.
- Returns `{ ok, target, imported, skipped, errors }`.

### 3. `src/components/admin/bulk-upload-form.tsx`

Client component with shadcn/ui Tabs:

**Tab 1 — CSV Upload**:
- Drag-and-drop zone + click-to-select (hidden `<input type="file" accept=".csv">`).
- `FileReader.readAsText` → client-side `parseCsvClient()` (mirrors server parser).
- Accepts both snake_case and Spanish column aliases
  (`group_name | groupName | nombre | name`, `join_link | joinLink | enlace | url`,
  `categoria`, `pais`, `ciudad`, `etiquetas`, `palabras_clave`, `imagen`, `adulto`).
- File size cap (2 MB), file type validation, toast feedback.
- "Descargar plantilla CSV" button (Blob download of `csvTemplateString()`).

**Tab 2 — JSON Builder**:
- `<Textarea>` with monospace font, 14 rows, spellcheck off.
- Live JSON validation (green/red badge with error message).
- "Añadir fila" button appends an empty group object to the JSON.
- "Quitar última" pops the last element.
- "Aplicar y validar" parses JSON and loads rows into the preview.
- Default JSON seed: one example group (Cocina Mexicana Tradicional) for reference.

**Both tabs share**:
- Column-mapping guide card with 10 columns (required/optional badges, aliases,
  description) + scrollable chips list of all available categories + countries
  (loaded from the server-rendered page).
- Preview table (sticky header, max-h-[28rem] overflow-auto, custom
  Tailwind scrollbar styling inherited from globals.css) showing row #, group
  name, link, category, country, description (line-clamp-2), +18 badge, and
  validation status (green CheckCircle2 or red XCircle with `title=error`).
- Error summary panel under the table listing the first 6 errors with row
  number + group name + reason; "+N more" if there are more.
- Target selector: two big toggle cards (Grupos pendiente / Cola drip-feed)
  with icon + description + radio indicator.
- Import button (disabled while importing or when no valid rows).
- Result panel after import: green/amber banner with imported/skipped counts,
  collapsible error details list, target label.

**Sub-components**: `ColumnGuide`, `TargetOption` (radio-style button card).

### 4. `src/app/admin/bulk-upload/page.tsx`

- Server component, `checkAdmin()`-guarded (redirects to `/admin/login` if not authed).
- Parallel fetch: `categories` (active, sorted) + `countries` (active, sorted)
  + `groupsQueue.count()` + `group.count({ status: "pending" })` for the
  header badges.
- Renders: header bar (back button + title + queue/pending counts), intro
  card with reminder text (emerald accent), `<BulkUploadForm>`, "Cómo funciona"
  4-step card.
- Sticky footer via `min-h-screen flex-col` wrapper, `SiteHeader` + `SiteFooter`
  + `BackToTop`.

### 5. Admin Dashboard link

Updated `QUICK_ACTIONS` array in `src/app/admin/page.tsx`:
- Added `UploadCloud` to the lucide-react import.
- Inserted a new entry right after "Gestionar grupos":
  ```
  { href: "/admin/bulk-upload", title: "Carga masiva",
    desc: "Importa grupos desde CSV o JSON.", icon: UploadCloud }
  ```
- Now 7 quick-action cards (was 6), still fits the 2-column sm:grid layout.

---

## Verification

- **`bun run lint`** → 0 errors, 0 warnings.
- **`bunx tsc --noEmit`** filtered for `bulk-upload` and `bulk-import` → 0
  errors in my new files. (Pre-existing TS errors in untouched files were
  already present per worklog notes.)
- Dev server was paused at the time of verification (502 from Caddy; no new
  entries in dev.log after my code changes). The system is configured to run
  `bun run dev` automatically; on next preview request the new routes will
  compile and serve.

---

## Files Affected

**Created:**
- `src/lib/bulk-import.ts` (654 lines)
- `src/app/api/admin/bulk-upload/route.ts` (~110 lines)
- `src/components/admin/bulk-upload-form.tsx` (~700 lines)
- `src/app/admin/bulk-upload/page.tsx` (~165 lines)

**Modified:**
- `src/app/admin/page.tsx` (added `UploadCloud` import + 1 quick-action entry)

---

## Design / UX Notes

- Spanish UI throughout (titles, descriptions, errors, badges, toasts).
- Mobile-first: cards stack vertically on mobile, 2–3 columns on sm/lg.
- Touch targets ≥44px (large drag-drop zone, big target selector cards).
- Color system: emerald for primary actions, rose for errors, amber for
  warnings — no indigo/blue per project rules.
- Preview table uses sticky header (`sticky top-0 bg-card`) + max-height
  scroll (`max-h-[28rem] overflow-auto`) for long lists.
- Validation badge inline with table row (`title=` attribute on the X icon
  for quick tooltip, plus a detailed error summary panel below the table).
- Target selector uses big clickable cards with radio-style indicator
  (better touch UX than a native radio group on mobile).
- Result panel: collapsible `<details>` for error list (avoids huge scroll
  when there are many skips).

---

## Security / Edge Cases Handled

- **Admin auth** enforced via `checkAdmin()` (page) and `checkAdminApi()` (API).
- **CSRF** validated via `checkCsrfApi(body.csrf)` — token passed from server
  to client component as a prop.
- **Body size guard**: 500-row hard cap on the API + 2MB file size cap on the
  client.
- **Malformed input**: `try/catch` around `JSON.parse` in both client and
  server; per-row `try/catch` in `importGroups` so one bad row doesn't kill
  the whole batch.
- **DB-side dedup**: `db.group.findMany({ where: { joinLink: { in: [...] } } })`
  up-front, plus per-row slug uniqueness check via `ensureUniqueDbSlug`.
- **Intra-batch dedup**: `Map<string, number>` tracks slug/link → first
  rowIndex so duplicate-within-batch errors point back to the original.
- **Category isAdult sync**: if a row's category is `isAdult=true` but the
  row declared `is_adult=0`, the row is auto-flipped to `isAdult=true` to
  keep adult content properly isolated (per Groupizo CRITICAL_NOTES 7).
- **Tag stopwords** stripped per Groupizo SEO section.
- **SQL injection**: all DB access via Prisma's parameterized client.
- **XSS**: no `dangerouslySetInnerHTML` anywhere; all user input rendered via
  React's default escaping.
- **Logging**: `logAdminAction()` records every successful bulk import in the
  audit trail with target + counts + mode.
