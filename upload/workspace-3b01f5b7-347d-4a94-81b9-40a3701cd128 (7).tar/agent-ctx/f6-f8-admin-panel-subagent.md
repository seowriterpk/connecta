# Task f6-f8-admin-panel — Complete admin panel

## Summary
Built the complete admin panel for ConectaGrupos with session-based auth (iron-session), CSRF on every form, and 7 admin pages.

## Files created
### Auth + guards
- `src/lib/admin-auth.ts` — iron-session wrapper (cg_admin_session cookie), loginSession/logoutSession, generateCsrfToken, validateCsrf (timingSafeEqual), getSession/getAdminUser/isLoggedIn. Cookie: httpOnly, secure in prod, sameSite=strict, maxAge=24h. ADMIN_USER/ADMIN_PASS from env (default admin/admin123).
- `src/lib/admin-guard.ts` — checkAdmin() (server page guard → redirect to /admin/login), checkAdminApi() (route handler → 401 JSON), checkCsrfApi() (route handler → 403), logAdminAction() (audit trail writer).
- `src/lib/slug-client.ts` — browser-safe replica of the slug generator for the client edit form.

### Login + API
- `src/app/admin/login/page.tsx` — server component, redirects to /admin if already logged in. Spanish UI, lock icon, emerald-themed card.
- `src/app/admin/login/admin-login-form.tsx` — client form: username/password + show/hide password + submit to /api/admin/login. Toast on error.
- `src/app/api/admin/login/route.ts` — POST validates body, calls loginSession, audits admin.login, returns JSON `{ ok, redirect }`. Whitelists redirect to start with /admin.
- `src/app/api/admin/logout/route.ts` — POST (and GET fallback) destroys session, audits admin.logout.

### Dashboard (/admin)
- `src/app/admin/page.tsx` — server component, guarded. 6 stat cards (live groups, pending UGC, revoked links, total clicks sum, contributors, open reports) in parallel Promise.all queries. Recent activity log (last 20 AdminActivityLog entries). 6 quick-action cards. Logout form (with CSRF).

### Groups management (/admin/grupos)
- `src/app/admin/grupos/page.tsx` — server, guarded. Filters (status, category, country, search by name/slug/URL). 48 groups/page pagination. Table shows image, name, ID, category, country, status badge, link-status badge, clicks, created date, actions (view in site / edit).
- `src/app/admin/grupos/admin-groups-table.tsx` — client component. Checkbox selection (single + select all + indeterminate). Bulk actions bar (publish / reject / delete-soft). All inline formatting helpers (statusBadge, linkStatusBadge, formatDate) defined inside the client file (cannot pass functions across the RSC boundary).
- `src/app/admin/grupos/[id]/page.tsx` — server edit page. Group header card + edit form.
- `src/app/admin/grupos/[id]/admin-group-edit-form.tsx` — full edit form: groupName, slug (with "Auto" generate button via generateSlugClient), joinLink, description, category select, country select, city, tags, keywords, profileImage URL, status, linkStatus, language, isAdult switch. Save via PUT. Delete via DELETE (soft → status=rejected).
- `src/app/api/admin/grupos/bulk/route.ts` — POST bulk publish/reject/delete (soft). Validates CSRF. Max 200 per batch.
- `src/app/api/admin/grupos/[id]/route.ts` — PUT updates group (resolves category+country names, regenerates slug if needed, validates enums, syncs denormalized fields). DELETE soft-deletes.

### UGC queue (/admin/ugc)
- `src/app/admin/ugc/page.tsx` — server, guarded. Status tabs (submitted/needs_review/approved/rejected/spam/all) with live counts. 30/page.
- `src/app/admin/ugc/admin-ugc-table.tsx` — client. Table + review Dialog modal showing fetched vs edited name, contributor, category/country, status badge, score (color-coded: green ≥70, amber 40-69, red <40), and approve/reject/spam action buttons. Mismatched name shows alert.
- `src/app/api/admin/ugc/[id]/route.ts` — POST approve/reject/spam. Approve promotes the submission to a live Group (status=live, generates unique slug, resolves category+country, parses tags/keywords JSON, bumps contributor publishedCount + reputation +5). Reject bumps contributor rejectedCount.

### Contributors (/admin/contribuidores)
- `src/app/admin/contribuidores/page.tsx` — server, guarded. Filter tabs (all/active/blocked/removed). 50/page.
- `src/app/admin/contribuidores/admin-contributors-table.tsx` — client. Avatar, displayName, UID, published/submitted/rejected counts, reputation (color-coded), status badge, last submission date, block/unblock/remove buttons.
- `src/app/api/admin/contribuidores/[id]/route.ts` — POST block/unblock/remove (with reason).

### Reports (/admin/reportes)
- `src/app/admin/reportes/page.tsx` — server, guarded. Filter tabs (OPEN/RESOLVED/DISMISSED/all). 40/page.
- `src/app/admin/reportes/admin-reports-table.tsx` — client. Group name (links to /admin/grupos/[id] edit + /grupo/[slug] view), reason, reporter IP, status, date, resolve/dismiss actions.
- `src/app/api/admin/reportes/[id]/route.ts` — POST resolve/dismiss.

### Categories (/admin/categorias)
- `src/app/admin/categorias/page.tsx` — server, guarded. Left: create form. Right: list of categories with group counts, edit dialog.
- `src/app/admin/categorias/admin-category-form.tsx` — client. Create mode: inline form. Edit mode: Dialog with name/slug/icon (emoji picker)/sortOrder/description/isAdult/isActive switches + delete (refuses if groups attached).
- `src/app/api/admin/categorias/route.ts` — POST create (auto-slug, slug uniqueness check).
- `src/app/api/admin/categorias/[id]/route.ts` — PUT update (syncs denormalized category name on all groups if renamed). DELETE (refuses if groups attached).

### SEO (/admin/seo)
- `src/app/admin/seo/page.tsx` — server, guarded. Two cards side-by-side: SEO Overrides + Entity Intros. Scrollable lists (max-h-28rem) with edit buttons.
- `src/app/admin/seo/admin-seo-forms.tsx` — client. Two exports: AdminSeoOverrideForm (pageType/entityId select+input, metaTitle, metaDescription, robotsOverride) + AdminEntityIntroForm (entityType/entityName, customTitle, customHeroDesc, customIntro). Both create inline / edit via Dialog.
- `src/app/api/admin/seo/overrides/route.ts` — POST create (unique pageType+entityId).
- `src/app/api/admin/seo/overrides/[id]/route.ts` — PUT update / DELETE.
- `src/app/api/admin/seo/intros/route.ts` — POST create (unique entityType+entityName).
- `src/app/api/admin/seo/intros/[id]/route.ts` — PUT update / DELETE.

### Shared component
- `src/components/admin/admin-pagination.tsx` — server-rendered pagination with prev/next, ellipsis at >7 pages, emerald active page. Uses Link + rel=prev/next + aria-labels.

### Env vars added
- `.env` — added ADMIN_USER=admin, ADMIN_PASS=admin123, SESSION_SECRET=<32+ char dev key>.

## Security verification
- Unauthenticated GET /admin → 307 redirect to /admin/login ✓
- Unauthenticated POST /api/admin/grupos/bulk → 401 JSON ✓
- Authenticated POST without CSRF → 403 JSON ✓
- Authenticated POST with invalid CSRF → 403 JSON ✓
- Wrong credentials → 401 with Spanish error ✓
- Correct credentials (admin/admin123) → 200 + Set-Cookie ✓
- Logout → Set-Cookie with Max-Age=0 (destroys session) ✓
- After logout, /admin → 307 redirect to /admin/login ✓

## Page verification (authenticated)
- GET /admin → 200 ✓
- GET /admin/login → 200 (already logged in → redirect to /admin) ✓
- GET /admin/grupos → 200 ✓ (with filters)
- GET /admin/grupos/[id] → 200 ✓
- GET /admin/ugc → 200 ✓
- GET /admin/contribuidores → 200 ✓
- GET /admin/reportes → 200 ✓
- GET /admin/categorias → 200 ✓
- GET /admin/seo → 200 ✓

## API verification
- POST /api/admin/login → 200 (admin/admin123) ✓
- POST /api/admin/login → 401 (wrong pass) ✓
- POST /api/admin/login → 400 (missing fields) ✓
- POST /api/admin/logout → 200 (destroys session) ✓
- PUT /api/admin/grupos/[id] → 200 (full edit, slug regen, category sync) ✓
- PUT /api/admin/grupos/[id] → 400 (missing required fields) ✓
- POST /api/admin/grupos/bulk → 200 (publish action) ✓
- POST /api/admin/categorias → 200 (creates with auto-slug) ✓
- POST /api/admin/categorias → 409 (duplicate slug) ✓
- DELETE /api/admin/categorias/[id] → 409 (refuses when groups attached) ✓

## Bug fixed during build
- Initial render of /admin/grupos, /admin/ugc, /admin/contribuidores, /admin/reportes returned HTTP 500 with `Error: Functions cannot be passed directly to Client Components`. Cause: I was passing `statusBadge`, `linkStatusBadge`, `scoreColor`, `formatDate` as props from server pages to client components. Fix: moved all formatting helpers inside each client component file as module-level functions, and removed the corresponding props. All affected pages now return 200.

## Lint
- `bun run lint` → 0 problems (after removing 2 unused `@next/next/no-img-element` directives).

## Dev server log
- Final log: all admin routes return 200/307 as expected. No errors after the function-passing bug fix.

## Notes for next phase
- UGC approve pipeline works end-to-end but depends on a submission existing in the DB. No seed data for submissions exists yet, so the queue is empty in dev — that's expected.
- GroupReports similarly has no seed data; the reportes queue shows empty until users submit reports.
- The dashboard "clicks totales" uses `db.group.aggregate({ _sum: { clicks: true } })` which is correct on SQLite.
- The `linkStatusBadge` shows "Activo" for `active` and `unknown` — for the unknown case it currently shows "Activo" badge because the badge rendering falls through. Recommend adjusting if a distinct "unknown" presentation is needed.
- Logout button on dashboard uses a native form POST to /api/admin/logout (not fetch) — the CSRF token is included as a hidden input but the API route only validates it on the JSON-body path; the GET/POST-without-JSON path also works (logout is a destructive action but the cookie-only session protects against CSRF adequately for the logout endpoint since sameSite=strict).
