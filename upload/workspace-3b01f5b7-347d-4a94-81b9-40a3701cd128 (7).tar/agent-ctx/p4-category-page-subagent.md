# Task ID: p4-category-page
Agent: subagent (category page implementer)
Task: Create the category listing page at `src/app/categoria/[slug]/page.tsx`.

## Context loaded
- Read `/home/z/my-project/worklog.md` (project overview + cron-1..9 history).
- Read existing reference files:
  - `src/app/grupo/[id]/page.tsx` (sibling detail page; breadcrumb + JSON-LD pattern).
  - `src/app/page.tsx` (SiteHeader placement, section ordering).
  - `src/app/layout.tsx` (root layout already injects global JSON-LD; no SiteHeader at root).
  - `src/lib/data.ts` — confirmed signatures:
    - `getCategoryBySlug(slug)` → `{ id, name, slug, description, icon, color, sortOrder, groupCount } | null`
    - `getGroupsByCategorySlug(slug, limit = 60)` → `GroupDTO[]` (includes `category` + `country` via `include`).
    - `getRatingsBatch(ids[])` → `Record<string, { avg, count }>`.
    - `getCategories()` and `getCountries()` needed for SubmitDialog.
  - `src/lib/types.ts` — `GroupDTO` shape with optional `category`/`country`.
  - `src/components/site/group-card.tsx` — signature `GroupCard({ group, rating })`.
  - `src/components/site/submit-dialog.tsx` — needs `categories + countries + trigger`.
  - `src/components/site/back-to-top.tsx`, `reveal.tsx`, `header.tsx` — all client components safe to render from a server parent.
  - `prisma/schema.prisma` — Category has `slug @unique`, `icon`, `color`, `description`.
  - `prisma/seed.ts` — 20 categories with slugs like `amistad`, `tecnologia`, `deportes`, etc.

## Plan
1. Server component (no `"use client"`).
2. `export const revalidate = 300`.
3. `generateMetadata({ params }: { params: Promise<{ slug: string }> })` async; title = `{category.name} — Grupos de WhatsApp | ConectaGrupos`.
4. Default export `CategoryPage({ params })`:
   - `await params`, `getCategoryBySlug(slug)`, `notFound()` if null.
   - `Promise.all([getGroupsByCategorySlug(slug), getCategories(), getCountries()])`.
   - `getRatingsBatch(groups.map(g => g.id))`.
5. JSON-LD: `ItemList` (groups as ListItem entries) + `BreadcrumbList`.
6. Breadcrumb nav (Inicio > Categorías > {category.name}).
7. Category header: icon, name, description, group count badge.
8. Grid of `GroupCard` (`grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4`).
9. Empty state if no groups.
10. Long-form Spanish SEO content (3 original paragraphs).
11. CTA section with `SubmitDialog`.
12. Wrap: `flex min-h-screen flex-col` → `SiteHeader` → `main flex-1` → `BackToTop`.

## Work Log
- Created `/home/z/my-project/agent-ctx/p4-category-page-subagent.md` (this file).
- Wrote `/home/z/my-project/src/app/categoria/[slug]/page.tsx`.
- Ran `bun run lint` (see worklog for result).

## Verification Results
- `bun run lint` → 0 problems.
- `bunx tsc --noEmit` → no errors in the new file (pre-existing errors in unrelated files).
- curl `GET /categoria/tecnologia` → HTTP 200, 135KB. Title rendered exactly as `Tecnología — Grupos de WhatsApp | ConectaGrupos` (used `title: { absolute }` to bypass root layout template). ItemList JSON-LD present with 2 ListItem entries. BreadcrumbList present. 3-paragraph SEO content + empty/CTA sections all rendered.
- curl `GET /categoria/amistad` → HTTP 200, 144KB.
- curl `GET /categoria/este-slug-no-existe` → HTTP 404 (notFound() works).
- dev.log: clean compile (no errors/warnings).

## Fixes During QA
- Typo in 3rd SEO paragraph: "forms parte" → "formas parte".
- Title template: root layout's `%s · ConectaGrupos` template was double-suffixing my title. Switched to `title: { absolute: title }` to render exactly as specified.

## Final Status
✅ Complete — file written, lint clean, runtime verified, worklog appended.
