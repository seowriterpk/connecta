# Task f11-phase4-pages — Search, Tag, Author & RSS pages

**Task ID:** f11-phase4-pages
**Agent:** subagent (fullstack)
**Goal:** Build the 4 remaining SEO pages — `/buscar`, `/etiqueta/[slug]`, `/autor/[slug]`, `/rss`.

## What was built

### 1. `/buscar` — Search page (server component)
- File: `src/app/buscar/page.tsx`
- Client companion: `src/components/site/search-box.tsx` (SearchBox with router.push, autoFocus, X-clear button, label `Buscar grupos`)
- Reads `searchParams.q` (Promise in Next.js 16)
- **AND-words full-text search**: split `q` on whitespace, lowercase, dedupe; build
  `AND: [{ OR: [ groupName / description / tags / keywords contains word ] }, ...]`
  with `status: "live", isAdult: false` filter.
- 48 results cap (configurable) in a responsive grid (`grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4`) using `GroupCard`.
- SEO:
  - `title.absolute` = `Buscar: {query} — ConectaGrupos` (with q) or `Buscar grupos de WhatsApp — ConectaGrupos` (landing)
  - `robots`: `noindex, follow` if total < 5; `index, follow` if ≥ 5.
  - Canonical = `${SITE.url}/buscar?q=...`
- JSON-LD: `SearchResultsPage` (always emitted, contains an `ItemList` of the first 10 results) + `BreadcrumbList` (Inicio > Buscar > q).
- Breadcrumb UI: Inicio > Buscar > {query}.
- Search hero with pre-filled SearchBox + stats badges ("X resultados", "Comunidades en español", "Pocos resultados · noindexado" when <5).
- Empty state ("No encontramos grupos…") with CTAs (Ver categorías, Explorar grupos, Enviar un grupo).
- Long-form SEO content section under the grid (only when there are results).
- Landing state when no `?q=`: hero + SearchBox autoFocus + suggestions cards + CTA.
- `SiteHeader + SiteFooter + BackToTop` wrapper.

### 2. `/etiqueta/[slug]` — Tag page (server component)
- File: `src/app/etiqueta/[slug]/page.tsx`
- Params + searchParams both Promises.
- Reverse-lookup tag name from slug via `getTagBySlug` (scans every live non-adult group's tags JSON, slugifies each via `citySlug`, returns the most-common variant).
- `getGroupsByTagPaginated(tagName, page)`: 48 per page, `where: { status: "live", isAdult: false, tags: { contains: '"tagName"' } }`, ordered by clicks desc → views desc → createdAt desc.
- `getRelatedTags(tagName, 16)`: top 16 co-occurring tags (excludes self), shown as chips with counts.
- `notFound()` when tag doesn't exist.
- Pagination via existing `Pagination` component (`?page=N` pattern).
- SEO:
  - title = `Grupos de WhatsApp con la etiqueta «{tag.name}» | ConectaGrupos`
  - `robots`: `index, follow` if total ≥ 10; `noindex, follow` otherwise.
  - Canonical = `${SITE.url}/etiqueta/{slug}` (with `?page=N` for pages > 1).
- JSON-LD: `ItemList` (all groups on the page as `ListItem`s) + `BreadcrumbList` (Inicio > Etiquetas > #tag).
- Breadcrumb UI: Inicio > Etiquetas > #{tag.name}.
- Header card: Tag icon (emerald) + h1 `#{tag.name}` + count badges.
- Empty state + CTA "Enviar un grupo".
- Related tags section (only if related tags exist).
- Long-form SEO content section.
- `SiteHeader + SiteFooter + BackToTop` wrapper.

### 3. `/autor/[slug]` — Author profile page (server component)
- File: `src/app/autor/[slug]/page.tsx`
- `generateStaticParams()` fetches all uploader slugs.
- `getUploaderBySlug(slug)` returns `UploaderDTO`; `notFound()` if missing.
- `getGroupsByUploader(uploaderId, 60)`: live, non-adult groups, ordered by clicks → views → createdAt.
- `getUploaderCategories(uploaderId)`: distinct categories covered (for stats + chip list).
- Profile card: avatar (GroupImage, fallback 👤), job title (BadgeCheck icon), h1 = full name, bio, social links as rounded buttons (Facebook / Twitter / LinkedIn / Website — only those the uploader has).
- Stats badges: total groups, categories covered, "En ConectaGrupos desde {date}" (es-ES format), total members across communities, "Grupos verificados" badge if any.
- Group grid (GroupCard with rating badges).
- Categories covered chip list (links to /categoria/[slug]).
- SEO:
  - title = `{name} — {jobTitle} | ConectaGrupos`
  - canonical = `${SITE.url}/autor/{slug}`
  - `robots: index, follow`
  - OG type = `profile`, image = uploader avatar.
- JSON-LD:
  - `Person` with `@id`, name, url, jobTitle, description, image, `worksFor: { Organization: ConectaGrupos }`, `sameAs: [...]` (array of social URLs).
  - `ProfilePage` with `about: { @id: person }` + `mainEntity: ItemList` of up to 12 groups.
  - `BreadcrumbList` (Inicio > Autores > name).
- Breadcrumb UI: Inicio > Autor > {name}.
- Empty state (when uploader has no visible groups): keeps the profile but shows CTA cards.
- Long-form SEO content section ("Sobre {name}") with stats summary.
- `SiteHeader + SiteFooter + BackToTop` wrapper.

### 4. `/rss` — RSS 2.0 feed (route handler)
- File: `src/app/rss/route.ts`
- `export const revalidate = 3600` (1h ISR).
- `getNewestGroupsForRss(50)`: 50 newest live non-adult groups ordered by createdAt desc.
- Returns RSS 2.0 XML:
  - `Content-Type: application/rss+xml; charset=UTF-8`
  - `Cache-Control: public, max-age=3600, s-maxage=3600, stale-while-revalidate=86400`
  - `X-Content-Type-Options: nosniff`
  - Channel: title, link, description, language=es-ES, lastBuildDate/pubDate, ttl=60, generator, managingEditor, webMaster, image (favicon.svg)
  - `atom:link rel="self"` to `/rss` + `atom:link rel="related"` to `/sitemap.xml`
  - Per item: `<title>` (groupName), `<link>` (`${SITE.url}/${slug}` absolute), `<guid isPermaLink="true">`, `<description>` (truncated to 320 chars), `<category>` (category name), `<author>` (uploader name), `<source>` (country name), `<pubDate>` (RFC-822 from createdAt)
- All XML special chars (&, <, >, ", ') properly escaped.

## Data helpers added (`src/lib/data.ts`)
Appended at end of file (no existing functions modified):
- `searchGroups(q, limit=48)` — AND-words full-text search across groupName/description/tags/keywords (case-insensitive via Prisma `contains` which is default case-insensitive in SQLite LIKE).
- `getTagBySlug(slug)` — reverse-lookup tag name from slug.
- `getGroupsByTagPaginated(tagName, page)` — 48/page paginated query.
- `getRelatedTags(tagName, limit=16)` — co-occurring tags.
- `getUploaderBySlug(slug)` → `UploaderDTO`.
- `getAllUploaderSlugs()` — for `generateStaticParams`.
- `getGroupsByUploader(uploaderId, limit=60)`.
- `getUploaderCategories(uploaderId)` — distinct categories for the stats card.
- `getNewestGroupsForRss(limit=50)`.
- Exported `UploaderDTO` type.

## Sitemap & robots
- `src/app/sitemap.ts` updated to include:
  - `/buscar` (priority 0.8, weekly)
  - `/rss` (priority 0.4, hourly)
  - `/etiqueta/{slug}` for every tag with ≥2 groups (priority 0.7, weekly)
  - `/autor/{slug}` for every uploader (priority 0.7, weekly)
- `robots.ts` already allows `/` and disallows `/api/`, so `/rss`, `/buscar`, `/etiqueta`, `/autor` are all crawlable.

## Files created
- `src/app/buscar/page.tsx` (~470 lines)
- `src/app/etiqueta/[slug]/page.tsx` (~370 lines)
- `src/app/autor/[slug]/page.tsx` (~370 lines)
- `src/app/rss/route.ts` (~95 lines)
- `src/components/site/search-box.tsx` (~85 lines)

## Files modified
- `src/lib/data.ts` — appended 7 new exported data helpers + `UploaderDTO` interface (~210 new lines).
- `src/app/sitemap.ts` — extended with /buscar, /rss, /etiqueta/*, /autor/* entries.

## Verification
- `bun run lint` → 0 errors, 0 warnings (after removing an unused eslint-disable directive).
- Started dev server briefly to verify end-to-end (system wasn't running it):
  - `GET /buscar` → 200
  - `GET /buscar?q=cafe` → 200 (1 result, noindex meta)
  - `GET /buscar?q=futbol` → 200 (1 result, noindex meta)
  - `GET /buscar?q=no-existe-esto` → 200 (empty state)
  - `GET /etiqueta/charlar` → 200 (2 groups, noindex meta, ItemList + BreadcrumbList JSON-LD)
  - `GET /etiqueta/cine` → 200
  - `GET /etiqueta/no-existe-esta-etiqueta-xxx` → 404 (notFound)
  - `GET /autor/lucia-martinez` → 200 (Person + ProfilePage + BreadcrumbList JSON-LD; sameAs = [facebook, twitter, linkedin])
  - `GET /autor/diego-hernandez` → 200 (sameAs = [twitter, linkedin, website])
  - `GET /autor/maria-gonzalez` → 200 (sameAs = [facebook, website])
  - `GET /autor/carlos-ramirez` → 200 (sameAs = [facebook, twitter, linkedin])
  - `GET /autor/no-existe` → 404 (notFound)
  - `GET /rss` → 200, `Content-Type: application/rss+xml; charset=UTF-8`, valid RSS 2.0 with atom:link self-reference.
  - `GET /sitemap.xml` → 200 (extended with new entries).
- All Spanish UI text. Mobile-responsive grids (`grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4`).
- `mt-auto` footer + `flex min-h-screen flex-col` wrapper on every page (sticky footer pattern).
- Dev server then stopped (the system is supposed to manage `bun run dev`).

## Design choices / notes
- **Search AND-logic**: every whitespace-separated word in `q` must appear (in any of the 4 text fields) for a group to match. Implemented as `AND: words.map(w => ({ OR: [groupName/description/tags/keywords contains w] }))`. This is more useful for users who paste multi-word queries.
- **Robots strategy**:
  - `/buscar?q=...` noindex when <5 results (avoid thin search-result pages cluttering the index). Landing `/buscar` is indexable.
  - `/etiqueta/[slug]` noindex when <10 groups (avoid thin tag pages).
  - `/autor/[slug]` always indexable (each author is a stable E-E-A-T page).
  - `/rss` is a feed, not crawled as HTML — but listed in sitemap with hourly changeFrequency.
- **Tag slug reverse-lookup**: there is no `tags` table, only the JSON `tags` column on each group. `getTagBySlug` scans every live non-adult group's parsed tags and finds the one whose `citySlug(tag)` matches the URL slug. Returns the most common variant (in case "Café" and "cafe" both appear in the data). This is acceptable for the current scale (30 groups → ~150 tags); at >10k groups we'd denormalize into a `Tag` table.
- **RSS link absolutization**: the task spec said `link (`/${slug}`)` (path-only), but RSS 2.0 requires absolute URLs. I produce `${SITE.url}/${slug}` (which matches the existing group page canonical: `${SITE.url}/${group.slug}`).
- **Person schema sameAs**: includes every URL the uploader has (facebook, twitter, linkedin, website). When the uploader has no socials, the `sameAs` key is omitted entirely (cleaner JSON-LD than `sameAs: []`).
- **`generateStaticParams` for /autor**: returns all uploader slugs (4 in the current seed). The page still works for not-yet-known slugs in dev (dynamic fallback) and 404s cleanly via `notFound()` when the uploader truly doesn't exist.

## Unresolved / next-phase recommendations
- Search is currently substring-based (Prisma `contains` over 4 fields, SQLite LIKE). At >10k groups this will slow down; a real FTS5 virtual table or Postgres `tsvector` would scale better. The Prisma schema already has indexes on `status`, `isAdult`, `clicks`, `views`, `createdAt`.
- Tag pages do an N-groups scan on every request for `getTagBySlug`. Could be cached with `unstable_cache` keyed by slug, or materialized into a `Tag` model with `@@map("tags")` and a `GroupTag` join table when the directory grows.
- `/buscar` has no autocomplete or "did you mean" suggestions; could wire a debounced GET to `/api/groups?search=` with the existing API.
- `/autor` shows all groups on one page (up to 60). When an author publishes >60, switch to paginated (`getGroupsByUploaderPaginated` is a 1-line extension of `getGroupsByTagPaginated`).
- RSS could be extended with `<enclosure>` images per item (currently uses text + link only). WhatsApp profile images are tiny and may not add much value.
- `/etiqueta` index page (list all tags) is not yet built — currently the tag landing exists only as the related-tags chips on each tag page. A `/etiqueta` index would aid discoverability.
- `/autor` index page (list all authors) is not yet built — same situation.
