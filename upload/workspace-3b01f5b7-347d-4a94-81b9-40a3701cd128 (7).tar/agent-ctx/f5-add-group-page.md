# Task f5-add-group-page — Build /agregar-grupo (7-step UGC form) + UGC submission backend pipeline

## What changed

### NEW: /agregar-grupo page (server component)
- `src/app/agregar-grupo/page.tsx`
- SEO metadata (title absolute, description, canonical, OG/Twitter, robots index,follow).
- revalidate=300 (5min ISR).
- JSON-LD WebPage + BreadcrumbList.
- Fetches `getCategories` + `getCountries` from @/lib/data, passes them to <AddGroupForm>.
- Wraps with SiteHeader + SiteFooter + BackToTop. Includes breadcrumb + header with badges (verificación instantánea, puntuación de calidad, auto-publicación ≥70, países count) + long-form SEO content section.

### NEW: AddGroupForm client component (7 steps)
`src/components/site/add-group-form.tsx` (~35KB):
- **Step 1**: WhatsApp invite URL + "Verificar enlace" button → POST /api/groups/verify-invite. Shows preview card (image + fetched name) only if status=active. Spanish error states for revoked/unknown/invalid.
- **Step 2**: Country pill grid (with search filter, max-h-80 scroll) + optional city input.
- **Step 3**: Category pill grid (filters out `isAdult=true` per Groupizo manual).
- **Step 4**: Group name (prefilled from og:title, editable) + description (20-600 with counter + color states) + live slug preview using `generateSlug` from @/lib/slug (client-safe).
- **Step 5**: Tags (3-6, chip input, Enter/comma to add, Backspace to remove) + Keywords (3-6 same UX). Live quality-score preview (debounced 350ms POST /api/groups/preview-score) → Progress bar with color (emerald ≥70, amber 40-69, destructive <40) + label.
- **Step 6**: Contributor RadioGroup — anonymous OR profile (display name + passkey). Name availability debounced (400ms) → GET /api/groups/check-name. Shows @slug hint when available, reason when not.
- **Step 7**: Review summary (dl of all fields + tags/keywords as badges + score Progress). Honeypot hidden input `website_url` rendered absolutely off-screen. Submit → POST /api/groups/submit-ugc.

UX:
- Step dots component with check icon for completed steps.
- Back/Continue/Submit buttons. `canAdvance(step)` validates before allowing forward.
- On mount: fetches CSRF token, generates persistent deviceToken (localStorage), records startedAt timestamp (kept fresh for 30min so user can navigate steps without being flagged as bot).
- Success view: status-aware card (auto_published → "¡Publicado automáticamente!" with link to /slug; submitted → "En cola de revisión"; rejected → "No superó las normas"). Shows score badge.
- All UI text Spanish. Mobile responsive (grid-cols-2 sm:grid-cols-3 pill grids). Uses existing shadcn/ui: Button, Input, Textarea, Label, Badge, Progress, RadioGroup.

### NEW: /api/groups/csrf-token (GET)
`src/app/api/groups/csrf-token/route.ts`
- Cookie-based double-submit CSRF. Generates 32-byte hex token, sets httpOnly `cg_ugc_csrf` cookie (1h, SameSite=Lax, secure in prod), returns { ok, token, expiresIn } in JSON.

### NEW: /api/groups/verify-invite (POST)
`src/app/api/groups/verify-invite/route.ts`
- Body: `{ url }`. Validates format with `isValidWhatsAppInvite`. Calls `fetchWhatsAppMeta` (shared lib, iPhone UA, 8KB preview, 3-state).
- Returns `{ ok, data: { status, groupName, imageUrl, inviteCode, description } }` or 422 (revoked) / 503 (unknown) / 400 (invalid). All error strings in Spanish.

### NEW: /api/groups/preview-score (POST)
`src/app/api/groups/preview-score/route.ts`
- Body: `{ hasInviteCode, hasGroupName, hasCategory, hasCountry, hasCity, tagsCount, keywordsCount, hasImage, hasLanguage, isContributor, text }`.
- Calls `hunterScan(text)` + `calculateScore(...)` (isDuplicate=false, submissionTimeSec=30 to avoid preview-flagging as bot).
- Returns `{ ok, data: { score, label, decision, flags, breakdown, hunterHits, hunterSevere, hunterAdult } }`.

### NEW: /api/groups/check-name (GET)
`src/app/api/groups/check-name/route.ts`
- Query: `?name=`. Validates length (3-32) + pattern (letters/digits/spaces/hyphens/underscores, with Spanish accents). Generates displaySlug via `generateSlug`. Queries `db.ugcContributor.findUnique({ where: { displaySlug } })`.
- Returns `{ ok, available, slug, reason }`.

### NEW: /api/groups/submit-ugc (POST) — full UGC pipeline (18KB)
`src/app/api/groups/submit-ugc/route.ts`

Steps:
1. **CSRF**: `timingSafeEqual(cookie cg_ugc_csrf ↔ body csrfToken)`. 403 if mismatch.
2. **Honeypot**: body `website_url` filled → fake success `{ ok:true, slug:"spammer", status:"auto_published" }` without persisting.
3. **Speed bot**: elapsed < 3s → 400 "Envío demasiado rápido".
4. **URL**: `isValidWhatsAppInvite` + `extractInviteCode`.
5. **Backend re-fetch**: `fetchWhatsAppMeta` (NEVER trust frontend).
6. **Link status**: status=revoked → 422. status=unknown → 422 (treat as invalid in UGC context, since we cannot publish a group we cannot verify).
7. **Category gatekeeper**: `db.category.findUnique` + `isActive`.
8. **Country gatekeeper**: `db.country.findFirst` + `isActive`.
9. **Rate limit**: `checkUgcRateLimits(ip, deviceToken)` — 10/device/day, 30/IP/day. 429 if exceeded.
10. **Duplicate**: `detectDuplicate(inviteUrl)` (LIKE %code% on groups + ugc_submissions).
11. **Content scan**: `hunterScan(groupName + tags + keywords + description)`.
12. **Quality score**: `calculateScore({ ...input, hunterResult, isAdultDeclared, submissionTimeSec: elapsedSec })`.
13. **Contributor profile** (handled before decision):
    - mode="profile" + displayName (3-32) + passkey (6-64).
    - Generate displaySlug. Hash passkey with bcrypt (10 rounds).
    - Existing contributor → verify passkey via `bcrypt.compare`; bump submittedCount + lastSubmissionAt + ipHashLast + deviceTokenHash.
    - New → create with contributorUid, internalUsernameKey, ipHashFirst/Last, deviceTokenHash, submittedCount=1.
    - If isBlocked||isRemoved → 403.
14. **Bump rate-limit counters** (`hitRateLimit` × 2).
15. **Decision**:
    - `drop_silently` → fake success `{ ok:true, slug:"pending", status:"submitted" }` (no DB write beyond what contributor already did).
    - `auto_publish` (≥70, no severe hits, not dup):
      * Generate unique slug via `makeUniqueSlug(baseSlug, existsFn)`.
      * INSERT into Group: status="live", linkStatus="active", submitSource="ugc", isAdult=isAdultDeclared, lastValidatedAt=now, imageRefreshedAt=now.
      * INSERT into UgcSubmission: status="auto_published", publishedGroupId=created.id, publishedAt=now.
      * Bump contributor publishedCount + reputationScore (+5).
      * Return `{ ok:true, slug:finalSlug, status:"auto_published", score }`.
    - `review` (≥40, severeHits<3): INSERT into UgcSubmission status="submitted". Return `{ ok:true, slug:"", status:"submitted", score }`.
    - `auto_reject`: INSERT into UgcSubmission status="rejected" + bump contributor rejectedCount. Return `{ ok:true, slug:"", status:"rejected", score }`.

### UPDATED: /enviar-grupo
- Replaced full page with `permanentRedirect("/agregar-grupo")` (308 Permanent Redirect). Old SubmitForm component file left in place (no longer imported by any source file).

### AUXILIARY
- `src/lib/types.ts`: added optional `isAdult?: boolean` + `isActive?: boolean` to CategoryDTO; added optional `isActive?: boolean` to CountryDTO.
- `src/lib/data.ts` `getCategories()`: now returns `isAdult` + `isActive` fields from DB rows.

## Verification
- `bun run lint` → **0 errors, 0 warnings**.
- `bunx tsc --noEmit` on my new files → **0 errors**. (Pre-existing TS errors in untouched files — admin-auth, content-hunter, country-canonicalizer, related-groups, whatsapp-validator, data.ts — were already present before this task.)

## Dependencies installed
- `bcryptjs@3.0.3`
- `@types/bcryptjs@3.0.0`

## Files created
- `src/app/agregar-grupo/page.tsx` (11KB)
- `src/components/site/add-group-form.tsx` (~35KB)
- `src/app/api/groups/csrf-token/route.ts` (1.4KB)
- `src/app/api/groups/verify-invite/route.ts` (2.4KB)
- `src/app/api/groups/preview-score/route.ts` (2.2KB)
- `src/app/api/groups/check-name/route.ts` (1.9KB)
- `src/app/api/groups/submit-ugc/route.ts` (18KB)

## Files updated
- `src/app/enviar-grupo/page.tsx` (replaced with `permanentRedirect`)
- `src/lib/types.ts` (added isAdult/isActive to CategoryDTO + CountryDTO)
- `src/lib/data.ts` (`getCategories` returns isAdult + isActive)

## Security checklist
- [x] CSRF: cookie-based double-submit (httpOnly, SameSite=Lax, 1h TTL, secure in prod) + `crypto.timingSafeEqual`.
- [x] Honeypot: hidden `website_url` field. Filled → fake success without persistence.
- [x] Speed bot: <3s elapsed → 400. started_at recorded client-side + persisted in localStorage (30min freshness).
- [x] Rate limit: 10/device/day + 30/IP/day via existing `checkUgcRateLimits`.
- [x] Backend re-fetch: `fetchWhatsAppMeta` called server-side in BOTH verify-invite AND submit-ugc — frontend claims never trusted.
- [x] Passkey: bcrypt hash (10 rounds). Existing contributor → `bcrypt.compare` on subsequent submissions.
- [x] Input validation: lengths, patterns, type coercion (`safeArray`, `String(...).trim().slice(...)`).
- [x] Generic error message to client, full detail logged server-side via `console.error`.

## Notes / next-phase recommendations
- Step 3 currently filters out isAdult categories for ALL users (no toggle). If a hidden "adult mode" is needed, add a client-side switch that reveals adult categories + flags `isAdultDeclared=true` on submission. The backend already handles isAdultDeclared via the category lookup.
- Image refresh cron (sharp 300x300 JPEG 80%) not yet wired; auto-published Group stores `meta.imageUrl` directly from WhatsApp CDN (per VIP_LOGIC notes, should be saved locally within 48h by the image-refresh cron once built).
- Drip feed (5/15min from `groups_queue`) is NOT used here — auto_publish bypasses the queue and goes live immediately. If drip-fed publishing is preferred, change the auto_publish branch to insert into `GroupsQueue` instead of `Group` (and set `UgcSubmission.status="approved"` + drip-feed will pick it up).
- No "approve from review queue → live Group" path here; the f6-f8 admin panel already handles that via `/api/admin/ugc/[id]` approve action.
