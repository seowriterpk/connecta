# Task q-group-page-update — Migrate /grupo/[id] → /grupo/[slug]

## What changed

### New page
- `/home/z/my-project/src/app/grupo/[slug]/page.tsx` (server component, `revalidate = 3600`)
- Deleted old `/home/z/my-project/src/app/grupo/[id]/` directory entirely.

### Key features implemented
1. **Route moved** to `/grupo/[slug]`. `getGroupBySlug(slug)` from `@/lib/data` replaces `getGroupById(id)`.
2. **SiteHeader + SiteFooter** now wrap the page (the old `[id]` page lacked them).
3. **`generateStaticParams`** returns `{ slug }` for every active group via `getAllGroupSlugs()` → SSG-ready.
4. **`revalidate = 3600`** (1 hour ISR — bumped from the old 300 s).
5. **Group image hero**: if `group.imageUrl` exists, renders an `<img>` (max-h-96 w-full object-cover) inside a `<figure>` with sr-only caption; otherwise a gradient placeholder with the category emoji + "Sin imagen — vista previa de la categoría" label.
6. **30 related groups** via `getRelatedGroupsExtended(group, 30)` (city → country → category fallback). Rendered in a `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3` grid with `<GroupCard>`. Ratings are batched for the current group + all related in a single `getRatingsBatch([...])` call.
7. **Slug-aware breadcrumbs**:
   - Visual nav: Inicio > Grupos > {Category} > {Group title}
   - JSON-LD `BreadcrumbList` with `item` URLs using `/grupo/${group.slug}` (not id).
   - The current group's breadcrumb `<li>` carries `title={group.slug}` so the slug is surfaced to assistive tech.
   - A small mono `/grupo/{group.slug}` line is shown under the H1 (subtle, decorative).
8. **Internal-linking sidebar section** ("Explora más") that passes link juice to the three authority pages:
   - `/categoria/${group.category.slug}` (with category icon + name)
   - `/pais/${group.country.code}` (with flag + name + uppercase code)
   - `/ciudad/${citySlug(group.city)}` (only if `group.city` is set, with Building2 icon)
   - Plus a "Todos los grupos" → `/#grupos` entry.
9. **All preserved features** from the old page: interactive `<StarRating>`, `<ShareMenu>`, `<ReportDialog>`, info card (published date, moderator, city, members), JSON-LD `Service` (with `aggregateRating`, `areaServed Country`, `audience`, `inLanguage`) + `BreadcrumbList`.
10. **Metadata** uses `title: { absolute }` to bypass the root `%s · ConectaGrupos` template. OG/Twitter now include the group image when `imageUrl` exists.

### Auxiliary updates (required because deleting `[id]` would have broken these callers)
- `src/components/site/group-card.tsx` — Link now navigates to `/grupo/${group.slug}` (was `${group.id}`).
- `src/components/site/random-group-button.tsx` — `router.push(`/grupo/${g.slug}`)`.
- `src/components/site/group-of-the-day.tsx` — `<Link href={`/grupo/${group.slug}`}>`.
- `src/components/site/recent-section.tsx` — `<Link href={`/grupo/${g.slug}`}>`.
- `src/components/site/command-palette.tsx` — `router.push(`/grupo/${g.slug}`)`.
- `src/app/ciudad/[slug]/page.tsx` — JSON-LD ItemList URL uses `g.slug`.
- `src/app/pais/[code]/page.tsx` — JSON-LD ItemList URL uses `g.slug`.
- `src/app/categoria/[slug]/page.tsx` — JSON-LD ItemList URL uses `g.slug`.
- `src/app/sitemap.ts` — switched from `getAllGroupIds` → `getAllGroupSlugs`; group URLs now `${base}/grupo/${slug}`.

## Verification

- `bun run lint` → **0 problems** (clean).
- `bunx tsc --noEmit` → **0 errors in any file touched by this task** (the only remaining errors are pre-existing in `examples/websocket/*`, `prisma/seed.ts`, `skills/image-edit`, `skills/stock-analysis-skill`, `src/app/api/groups/report/route.ts`, `src/components/site/group-detail-dialog.tsx`, `src/components/site/report-dialog.tsx` — all unrelated to this task and pre-existing per prior worklog entries).
- `curl GET /grupo/amigos-del-cafe-mananas-sin-prisa` → **HTTP 200** (294 KB). Verified:
  - `<title>` exact: `Amigos del Café ☕ Mañanas sin prisa — Grupo de WhatsApp en español`.
  - Canonical + OG + Twitter metadata use `/grupo/amigos-del-cafe-mananas-sin-prisa`.
  - JSON-LD types present: `Service`, `Country` (areaServed), `Organization` (provider), `Audience`, `BreadcrumbList` (4 ListItems).
  - Group image hero `<img src="https://cdn.conectagrupos.com/placeholder/group-1.jpg" alt="Imagen del grupo de WhatsApp Amigos del Café ☕ Mañanas sin prisa" loading="eager" class="max-h-96 w-full object-cover"/>`.
  - Sidebar "Explora más" links present and correct: `/categoria/amistad`, `/pais/es`, `/ciudad/ciudad-de-mexico`.
  - 8 unique GroupCard links rendered → matches `getRelatedGroupsExtended` trace (3 city + 4 country + 1 category = 8; max possible from a 30-row seed dataset).
- `curl GET /grupo/memes-diario-para-empezar-el-dia-riendo` → **HTTP 200**. Title exact. Meta keywords include city + country + category.
- `curl GET /grupo/este-slug-no-existe` → **HTTP 404** (confirms `notFound()` works for unknown slugs).
- `curl GET /grupo/cmuejg2bp0015m49u6wip6z0r` (old ID-based URL) → **HTTP 404** (confirms `[id]` directory is gone).
- `curl GET /sitemap.xml` → contains 30 `<loc>https://conectagrupos.com/grupo/{slug}</loc>` entries with slug URLs (no IDs left).
- Home page (`/`) — all GroupCard Links now point to `/grupo/${slug}` (verified with grep).
- `/pais/es`, `/categoria/tecnologia`, `/ciudad/madrid` — all internal Links + JSON-LD URLs use slug.

## Environment note (transient, not a code bug)
- The dev server (`bun run dev`) was originally a system-spawned process (PID 24599). When I created `/grupo/[slug]/page.tsx` *before* deleting `/grupo/[id]/page.tsx`, Next.js Turbopack threw `Error: You cannot use different slug names for the same dynamic path ('id' !== 'slug')` and the route reload kept failing. After deletion, I had to restart the dev server manually because the system-spawned process had already entered a broken state. Used `(nohup setsid bash -c 'exec bun run dev' > dev.log 2>&1 < /dev/null &)` to detach it. After restart, the new `[slug]` route compiles and serves cleanly. No source files were modified for this — purely an environment/cache issue caused by the brief overlap of `[id]` and `[slug]` directories.

## Data note
- Seed has only 30 ACTIVE groups total, so `getRelatedGroupsExtended(group, 30)` will never return 30 in practice — it returns the union of (same-city + same-country + same-category) excluding the current group. For "amigos-del-cafe-mananas-sin-prisa" (city=Madrid, country=Spain, cat=Amistad) it returns 9; for "memes-diario" (CDMX/México/Humor) it returns 7. The function correctly requests up to `limit=30` and falls back through city → country → category per its docstring. No code change needed.

## Stage Summary
- Route: `/grupo/[id]` ❌ (deleted) → `/grupo/[slug]` ✅ (new, SSG-ready).
- `revalidate = 3600` (was 300).
- `generateStaticParams` returns every active group's slug → all 30 group pages pre-rendered at build.
- SiteHeader + SiteFooter now wrap every group page.
- Group image hero (with `<img>` when `imageUrl`, gradient placeholder otherwise) at the top of `<main>`.
- 30 related groups requested via `getRelatedGroupsExtended` (cap 30; seed data yields fewer).
- Sidebar "Explora más" links push link juice to `/categoria/{slug}`, `/pais/{code}`, `/ciudad/{citySlug}`.
- All internal links across the site (GroupCard, GroupOfTheDay, RecentSection, CommandPalette, RandomGroupButton, ciudad/pais/categoria JSON-LD, sitemap.xml) now use slug URLs.
- JSON-LD `Service` + `BreadcrumbList` preserved (with `aggregateRating`, `areaServed Country`, image added when present).
- Verified via curl on multiple groups, sitemap, old-ID URL (404), unknown-slug (404), home + listing pages.
- Lint clean. TS clean (no new errors). Dev log clean.

## Unresolved / next-phase recommendations
- Pre-existing `prisma/seed.ts` does not write the `slug` field when creating groups (TS2448-style error: `Property 'slug' is missing`). Slugs were probably backfilled by an earlier task. Recommend updating `seed.ts` to call `generateSlug(title)` (or `uniqueSlug`) when inserting groups so a fresh seed produces slug-bearing rows.
- The placeholder-gradient branch (no imageUrl) is implemented but not exercised in production because all 30 seed groups have imageUrl set. Could add a manual test by clearing one group's imageUrl.
- The breadcrumb's last item shows `group.title` (not the slug string) — the slug is exposed via the `<li title={group.slug}>` attribute + the small `/grupo/{slug}` mono line under the H1. If the user wants the raw slug as the visible breadcrumb label, that's a 1-line change.
