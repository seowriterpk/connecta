# Task p5-country-page — Country listing page (`/pais/[code]`)

## Context loaded
- Read `/home/z/my-project/worklog.md` (full project history, all 10 prior tasks).
- Read reference sibling page `src/app/categoria/[slug]/page.tsx` (cron-3 subagent pattern).
- Read `src/lib/data.ts` lines 525-549: confirmed `getCountryByCode` returns `{ id, name, code, flag, region, dialCode, groupCount }` and `getGroupsByCountryCode(code, limit=60)` returns `GroupDTO[]`.
- Read `src/lib/types.ts`: `CountryDTO` shape.
- Read `src/lib/constants.ts`: `SITE.url`, `SITE.name` available.
- Read `src/components/site/group-card.tsx`: signature `GroupCard({ group, rating })`.
- Read `src/components/site/submit-dialog.tsx`: props are `{ categories, countries, trigger }` — does NOT accept `defaultCountryId` (so I removed that and let the user pick the country in the form).
- Read `prisma/seed.ts`: confirmed `dialCode` is stored WITH the `+` prefix (e.g. `"+52"`, `"+34"`). Adjusted code to avoid double-`+`.

## File written
`/home/z/my-project/src/app/pais/[code]/page.tsx` — server component, `export const revalidate = 300`, no `"use client"`.

## Page structure
1. `generateMetadata({ params: Promise<{ code: string }> })` — async Next.js 16 params. Calls `getCountryByCode(code)`. Returns `{ title: { absolute: "🇲🇽 México — Grupos de WhatsApp | ConectaGrupos" } }` (absolute bypasses the root layout `%s · ConectaGrupos` template, avoiding double-suffix). Includes description (mentions country + region + group count + keywords "grupos de WhatsApp en {country}"), canonical, openGraph (type website, locale es_ES, siteName), twitter (summary_large_image), Spanish keywords (with `{country.code}` uppercased for `MX`-style keyword).
2. Default export `CountryPage`:
   - `await params` → `getCountryByCode(code)` → `notFound()` if null.
   - Parallel `Promise.all([getGroupsByCountryCode(code, 60), getCategories(), getCountries()])`.
   - `getRatingsBatch(groups.map(g => g.id))` for card rating badges.
3. JSON-LD: **CollectionPage** with `about` → **Place** schema (name, description, telephone using dialCode directly since seed stores `+NN`, identifier = uppercase country code), `mainEntity` → **ItemList** with `numberOfItems` + per-group `ListItem` (position, name, url, category in description). Plus **BreadcrumbList** (Inicio → Países → {country.name}).
4. Layout: `flex min-h-screen flex-col` → `SiteHeader` → `main.flex-1` (breadcrumb, header, groups grid, SEO content, CTA) → `BackToTop`.
5. Breadcrumb (visual): Inicio > Países > {country.name}, with `ChevronRight` separators and `aria-label="Migas de pan"`.
6. Country header: large `{country.flag}` emoji (h-16/20 rounded-2xl bg-primary/10), `MapPin` + "País" eyebrow, `h1` "Grupos de WhatsApp en {country.name}", description paragraph, badges: group count (`Users`), region (`Globe2`), dial code (`Phone`), "Comunidades en español" (`MessageCircle`), conditional "Grupos verificados" (`ShieldCheck`) when any group is verified.
7. Groups grid: `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3` matching GroupsExplorer. Each `<GroupCard group={g} rating={ratings[g.id] ?? null} />`. Wrapped in `<Reveal>` for fade+slide.
8. Empty state: dashed border card with flag emoji + "Aún no hay grupos publicados en {country.name}" + `SubmitDialog` trigger.
9. Long-form SEO content: 4 original Spanish paragraphs (each mentions the country name naturally), covering:
   - P1: what the page gathers, the human-review quality gate, group count.
   - P2: how to choose (member count tradeoffs, dial code prefix mention, how to leave a group).
   - P3: how to submit your own group (free, pending review process).
   - P4: how to combine country + category filters, ordering, working from abroad.
   - Plus 3 internal links at the end: "Ver todos los países" → `/#paises`, "Explorar por categorías" → `/#categorias`, "Explorar todos los grupos" → `/#grupos`.
10. CTA: WhatsApp-emerald gradient banner with `{country.flag} ¿Administras un grupo en {country.name}?` pill + "Da visibilidad a tu comunidad" h2 + `SubmitDialog` "Enviar mi grupo ahora".

## Verification (curl + dev.log)
- `curl /pais/mx` → HTTP 200, 184KB. Title rendered EXACTLY as `🇲🇽 México — Grupos de WhatsApp | ConectaGrupos` (no `· ConectaGrupos` suffix). Verified JSON-LD types present: `CollectionPage`, `Place`, `ItemList`, `ListItem`, `BreadcrumbList`, `WebSite`. Dial code badge shows `+52` (single +). Telephone JSON-LD field = `+52`. Region badge shows "América del Norte". H1 = "Grupos de WhatsApp en México". SEO content mentions "grupos de WhatsApp en México" (count=2). CTA "Enviar mi grupo ahora" present. Breadcrumb `aria-label="Migas de pan"` present.
- `curl /pais/es` → HTTP 200, 167KB. Verified renders.
- `curl /pais/zz` → HTTP 404 (confirms `notFound()` works for unknown codes).
- dev.log: `GET /pais/mx 200 in 949ms (compile: 97ms, render: 852ms)`, `GET /pais/es 200`, `GET /pais/zz 404`. Clean compile, no errors/warnings.
- `bun run lint` → 0 problems.
- `bunx tsc --noEmit` → 0 errors in the new file.

## Fixes during QA
- **SubmitDialog `defaultCountryId`**: Initially added `defaultCountryId={country.id}` to pre-select the country in the submit form, but the existing `SubmitDialog` component does not accept that prop (would cause TS error). Removed all 3 usages — the form starts with the country field empty, consistent with how `categoria/[slug]` page uses it.
- **Doubled `+` in dial code**: Seed stores `dialCode` WITH the `+` (e.g. `"+52"`). My initial code had `+{country.dialCode}` (JSX badge), `+${country.dialCode}` (JSON-LD telephone), `+${country.dialCode}` (JSON-LD Place description), and `(prefijo +${country.dialCode})` (SEO paragraph), producing `++52`. Fixed by removing my extra `+` prefix in all 4 spots. Confirmed post-fix: `++52` count = 0, `+52` count = 14, `telephone: "+52"`.

## Stage summary
- New route: `/pais/[code]` (server component, `revalidate = 300`).
- SEO-complete: `generateMetadata` (title/description/canonical/OG/Twitter/keywords), JSON-LD `CollectionPage` + `Place` + `ItemList` + `BreadcrumbList`, breadcrumb nav, 4-paragraph original Spanish long-form content.
- Reuses existing components: `SiteHeader`, `GroupCard`, `BackToTop`, `Reveal`, `SubmitDialog`. No new components created, no other files modified.
- Mobile-first responsive grid: 1 → 2 → 3 → 4 columns at sm/lg/xl breakpoints.
- Empty state + 404 handled gracefully.
- Title uses `title: { absolute: ... }` to bypass root layout `%s · ConectaGrupos` template (so rendered title matches the spec exactly).

## Notes / next-phase recommendations
- Could add `generateStaticParams` exporting all 20 country codes to pre-render at build time (currently ISR with `revalidate=300`).
- Could add `/pais/[code]` routes to `sitemap.ts` (currently only `/#paises` anchor is in sitemap).
- `SubmitDialog` doesn't pre-select the country on country pages (component doesn't accept a default prop). A small enhancement to `SubmitDialog` to accept `defaultCountryId?` would make the UX even smoother — but that's a separate task.
- Long-form content is the same shape per country (only `country.name`/`region`/`dialCode`/`groupCount` vary); could be enriched with country-specific examples (local slang, popular cities, time zones) once we have country-specific copy.
