import mysql from 'mysql2/promise';
const pool = mysql.createPool({
  host: '31.97.208.160', port: 3306,
  user: 'u824913874_spanish', password: 'qX8t8=++L@c*',
  database: 'u824913874_spanishs',
});
try {
  const conn = await pool.getConnection();
  // Check table structures
  for (const t of ['groups', 'categories', 'countries', 'cities']) {
    const [cols] = await conn.query(`DESCRIBE \`${t}\``);
    console.log(`\n=== ${t} ===`);
    for (const c of cols) console.log(`  ${c.Field} ${c.Type} ${c.Null==='NO'?'NOT NULL':''} ${c.Key||''} ${c.Default!==null?'DEFAULT '+c.Default:''}`);
    const [count] = await conn.query(`SELECT COUNT(*) as c FROM \`${t}\``);
    console.log(`  ROWS: ${count[0].c}`);
  }
  // Sample groups
  const [gs] = await conn.query('SELECT * FROM groups LIMIT 2');
  console.log('\n=== SAMPLE GROUPS ===');
  for (const g of gs) console.log(JSON.stringify(g, null, 2).slice(0, 500));
  conn.release();
} catch (e) { console.error('FAILED:', e.message); }
finally { await pool.end(); }
