# ConectaGrupos — Guía de despliegue en Hostinger (MySQL)

Este documento explica cómo desplegar ConectaGrupos en Hostinger usando la base de datos
MySQL remota proporcionada. La app está construida con Next.js 16 + Prisma; en el sandbox
de desarrollo se usa SQLite, pero el esquema es 100% compatible con MySQL.

## 0. Requisitos de Node.js (LEER PRIMERO)

> **Versión recomendada: Node.js 22.x LTS**
>
> Selecciona **Node.js 22.x** en el selector de Hostinger (hPanel → Node.js →
> Deployment settings → Node.js version). Es la versión más estable y compatible
> con todo el stack.

### Matriz de compatibilidad (investigación oficial)

| Paquete              | Versión   | Node mínimo | ¿Compatible con 22? |
|----------------------|-----------|-------------|---------------------|
| Next.js              | 16.1.3    | ≥ 20.9.0    | ✓                   |
| Turbopack (Next 16)  | estable   | sigue Next  | ✓                   |
| Tailwind CSS v4      | 4.1.18    | ≥ 20 (binarios nativos) | ✓ |
| @tailwindcss/postcss | 4.1.18    | ≥ 20 (binarios nativos) | ✓ |
| Prisma               | 6.19.2    | ≥ 18.18     | ✓                   |
| iron-session         | 8.0.4     | ≈ 18+       | ✓                   |
| next-auth            | 4.24.11   | hereda Next | ✓                   |
| React                | 19.2.3    | sin límite  | ✓                   |

### Por qué 22.x y no otra

- **❌ Node 18**: EOL desde abril 2025. No ofrecido por Hostinger. Por debajo del mínimo de Next.js 16.
- **⚠️ Node 20**: Cumple los mínimos, pero LTS en mantenimiento termina **abril 2026** → obligaría a re-desplegar en meses. Evitar para producción nueva.
- **✅ Node 22 LTS**: Satisface todos los requisitos. Soporte hasta **abril 2027**. Máximo battle-testing con Turbopack, Prisma 6 y Tailwind v4 (binarios nativos de Rust).
- **⚠️ Node 24**: LTS nuevo (promovido oct 2025). Binarios nativos de `@tailwindcss/oxide` y Prisma pueden no tener cobertura completa para el ABI 24 en todas las plataformas → riesgo de `Cannot find module …native-*.node`. Seguro reconsiderar en Q1–Q2 2026.

### Configuración de `engines` en package.json

```json
"engines": { "node": ">=20.9.0" }
```

El campo permite 20/22/24, pero **recomendación explícita: 22.x LTS**.

### Si Hostinger NO ofrece 22.x en tu plan

Si solo ves 20.x disponible, usa 20.x (sigue siendo compatible, solo con soporte hasta abril 2026).
**Nunca uses 18.x** — está por debajo del mínimo de Next.js 16.

---

## 1. Credenciales MySQL (Hostinger)

| Campo | Valor |
|------|-------|
| Host | `srv939.hstgr.io` (o IP `31.97.208.160`) |
| Puerto | `3306` |
| Base de datos | `u824913874_spanishs` |
| Usuario | `u824913874_spanish` |
| Contraseña | `qX8t8=++L@c*` |
| Creada | 2026-09-24 |

> Importante: desde el panel de Hostinger debes añadir tu IP pública a la lista de IPs
> autorizadas para conectar al servidor MySQL (Remote MySQL).

## 2. Cambiar el provider de Prisma a MySQL

Edita `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}
```

Y en las variables de entorno (hPanel → Node.js → Environment Variables) define:

```
DATABASE_URL="mysql://u824913874_spanish:qX8t8%3D%2B%2BL%40c*@srv939.hstgr.io:3306/u824913874_spanishs"
```

La contraseña `qX8t8=++L@c*` debe ir URL-encoded → `qX8t8%3D%2B%2BL%40c*`
(`=` → `%3D`, `+` → `%2B`, `@` → `%40`).

## 3. Crear las tablas automáticamente (Schema Guard)

Como Hostinger no permite ejecutar `npx prisma migrate` por terminal, la app crea las
tablas automáticamente al arrancar si no existen. En producción, añade este bootstrap en
`src/lib/db.ts` (o un módulo `src/lib/schema-guard.ts`) que se ejecuta al iniciar:

```ts
import { db } from "@/lib/db";

export async function ensureSchema() {
  await db.$executeRawUnsafe(`CREATE TABLE IF NOT EXISTS countries (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    code VARCHAR(4) NOT NULL UNIQUE,
    flag VARCHAR(16) NOT NULL,
    region VARCHAR(64) NOT NULL,
    dialCode VARCHAR(8) NULL,
    createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
  ) CHARSET=utf8mb4;`);
  await db.$executeRawUnsafe(`CREATE TABLE IF NOT EXISTS categories (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    slug VARCHAR(140) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    icon VARCHAR(16) NOT NULL,
    color VARCHAR(32) NOT NULL,
    sortOrder INT NOT NULL DEFAULT 0,
    createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
  ) CHARSET=utf8mb4;`);
  await db.$executeRawUnsafe(`CREATE TABLE IF NOT EXISTS groups (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    inviteLink VARCHAR(400) NOT NULL,
    categoryId VARCHAR(64) NOT NULL,
    countryId VARCHAR(64) NOT NULL,
    members INT NOT NULL DEFAULT 0,
    isFeatured TINYINT(1) NOT NULL DEFAULT 0,
    isVerified TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    tags TEXT NOT NULL DEFAULT '[]',
    views INT NOT NULL DEFAULT 0,
    contactName VARCHAR(120) NULL,
    createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    INDEX idx_groups_cat (categoryId),
    INDEX idx_groups_country (countryId),
    INDEX idx_groups_status (status),
    INDEX idx_groups_featured (isFeatured),
    CONSTRAINT fk_groups_cat FOREIGN KEY (categoryId) REFERENCES categories(id),
    CONSTRAINT fk_groups_country FOREIGN KEY (countryId) REFERENCES countries(id)
  ) CHARSET=utf8mb4;`);
  console.log("Schema Guard: tablas verificadas");
}
```

Luego ejecuta el seed (`prisma/seed.ts`) una sola vez tras el primer despliegue
desde un entorno local con acceso MySQL autorizado, o importa un dump SQL.

## 4. Configuración de hPanel (Node.js app)

| Campo | Valor |
|-------|-------|
| Framework preset | Next.js |
| Node version | 20.x o 22.x |
| Root directory | `./` |
| Build command | `npm run build` |
| Start command | `npm run start` |
| Environment variables | `DATABASE_URL`, `NODE_ENV=production` |

## 5. Notas importantes

- **Un solo proceso, un solo puerto**: Hostinger asigna `process.env.PORT`. La config
  `output: "standalone"` de Next.js ya lo respeta.
- **Sin `node_modules` ni `.env` en el ZIP** (Hostinger hace `npm install`).
- **Incluye `package.json` y `package-lock.json`**.
- **Health check**: la ruta `/api/stats` responde 200 y sirve para verificar que la app
  y la base de datos están activas.
- **Caché**: `revalidate = 300` en categorías/países para reducir consultas a MySQL.

## 6. Migración de datos (seed inicial)

Tras crear las tablas, ejecuta el seed desde tu máquina local (con tu IP autorizada en
Hostinger Remote MySQL):

```bash
DATABASE_URL="mysql://u824913874_spanish:qX8t8%3D%2B%2BL%40c*@srv939.hstgr.io:3306/u824913874_spanishs" \
  bun run prisma/seed.ts
```

Esto carga los 20 países, 20 categorías y 30 grupos de demostración en español.

---

## 7. Solución de problemas: Turbopack + Tailwind v4 (CSS worker crash)

### Síntoma

El build (`next build`) o el dev server (`next dev`) muere sin error claro durante
el procesamiento de CSS. En el log aparece algo como:

```
✓ Compiled successfully
X [ERROR] Turbopack worker process exited unexpectedly
  while processing /app/src/app/globals.css
```

### Causa raíz

`postcss.config.mjs` usaba la forma de **array** para los plugins:

```js
// ❌ INCORRECTO — causa crash en Turbopack
const config = {
  plugins: ["@tailwindcss/postcss"],
};
```

Turbopack espera la forma de **objeto** (clave = nombre del plugin,
valor = opciones). El array de strings causa que el worker de CSS muera.

Referencias:
- https://github.com/vercel/next.js/discussions/90034
- https://stackoverflow.com/questions/79566892/

### Solución aplicada

`postcss.config.mjs` ahora usa la forma correcta:

```js
// ✅ CORRECTO — compatible con Turbopack
const config = {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};
export default config;
```

### Otros cambios relacionados

1. **Eliminado `tailwind.config.ts`** — Tailwind v4 usa config basada en CSS
   (`@theme inline { ... }` en `src/app/globals.css`). El archivo v3
   `tailwind.config.ts` ya no se referencia (no hay directiva `@config` en CSS)
   y su array `content` + plugin `tailwindcss-animate` causaban confusión.

2. **Eliminado `tailwindcss-animate`** (plugin v3) — reemplazado por
   `tw-animate-css` (v4 nativo) que ya está importado en `globals.css`:
   ```css
   @import "tw-animate-css";
   ```

3. **No añadir `autoprefixer`** — Tailwind v4 incluye su propio autoprefixer.
   Añadirlo como dep duplica el trabajo y puede causar conflictos.

### Si el problema reaparece tras un deploy

```bash
# 1. Verificar que postcss.config.mjs tiene la forma objeto
cat postcss.config.mjs
#   → debe mostrar: plugins: { "@tailwindcss/postcss": {} }

# 2. Borrar TODOS los cachés
rm -rf .next node_modules/.turbopack node_modules/.cache

# 3. Reinstalar (sin tailwindcss-animate)
bun install   # o npm ci

# 4. Reconstruir
bun run build

# 5. Si persiste, verificar versión de Node
node --version   # debe ser 22.x LTS
```

### Verificación rápida de que el CSS se compila

Tras arrancar el dev server, en el HTML de cualquier página debe aparecer:

```html
<link rel="stylesheet" href="/_next/static/chunks/...css" .../>
```

Y el `<body>` debe tener clases de Tailwind:

```html
<body class="... antialiased bg-background text-foreground">
```

---

## 8. Build de producción: usar webpack (no Turbopack)

> **CRÍTICO**: El script `build` en `package.json` usa `next build --webpack`.
> NO cambiar a `next build` (Turbopack) — hay un bug confirmado en Next.js
> 16.3.x donde Turbopack muere durante `PostCssTransformedAsset::process`
> en builds de producción.

### El bug

Al ejecutar `next build` (Turbopack, default en Next 16), el build muere con:

```
FATAL: An unexpected Turbopack error occurred.
Error [TurbopackInternalError]: Failed to write app endpoint /page

Caused by:
- [project]/src/app/globals.css [app-client] (css)
- creating new process
- node process exited before we could connect to it with exit status: 0
- Execution of parse_css failed
- Execution of <PostCssTransformedAsset as Asset>::content failed
- Execution of evaluate_webpack_loader failed
```

Turbopack lanza un proceso worker de Node para evaluar el plugin PostCSS
(`@tailwindcss/postcss`) como si fuera un webpack loader. El worker muere
silenciosamente (exit status 0) antes de que Turbopack pueda conectar vía IPC.

Esto **NO ocurre en dev** (dev usa Turbopack pero con configuración más
permisiva). Solo ocurre en `next build` (producción).

Referencias:
- https://github.com/vercel/next.js/discussions/90034
- El bug está presente en Next.js 16.3.8 (versión que npm instala desde `^16.1.1`)

### La solución

El script `build` en `package.json` ya está corregido:

```json
"build": "next build --webpack && cp -r .next/static .next/standalone/.next/ && cp -r public .next/standalone/"
```

El flag `--webpack` desactiva Turbopack y usa webpack para el build de
producción. Webpack es totalmente estable para este caso y produce el mismo
output standalone.

**Dev server sigue usando Turbopack** (más rápido, HMR instantáneo) — solo
el build de producción usa webpack.

### Verificación local antes de deploy

```bash
# Probar que el build compila (modo compile, no genera standalone)
./node_modules/.bin/next build --webpack --experimental-build-mode compile
# Debe terminar con exit code 0 y listar todas las rutas
```

### Si Hostinger sigue fallando tras este cambio

1. Verifica que el archivo subido tiene el `package.json` con `--webpack`:
   ```bash
   grep '"build"' package.json
   # → "build": "prisma generate && next build --webpack && ..."
   ```
2. En el log de build de Hostinger, la primera línea debe mostrar:
   ```
   > next build --webpack
   ```
   (NO `next build` solo)
3. Si por algún motivo Hostinger ejecuta `next build` sin el flag, añade un
   script explícito en `package.json`:
   ```json
   "hostinger-build": "next build --webpack"
   ```
   Y configura Hostinger para usar `npm run hostinger-build` como build command.

---

## 9. Build de producción: script personalizado (CRÍTICO)

> **El script `build` en `package.json` es: `"bash scripts/build.sh"`**
> Este script maneja TODOS los problemas de build en Hostinger.

### Los 3 problemas que resuelve

1. **Prisma provider sqlite → mysql**: El `schema.prisma` del repo usa
   `sqlite` para dev local. El script lo cambia a `mysql` antes de
   `prisma generate` (sin modificar el archivo fuente del repo).

2. **No hay DB durante el build**: Hostinger no tiene `DATABASE_URL` ni
   MySQL durante el build. Todas las páginas que consultan la DB tienen
   `export const dynamic = "force-dynamic"` → Next.js NO las pre-renderiza
   en build time, las renderiza en runtime cuando un usuario las visita.

3. **Turbopack crash en CSS**: Next.js 16.3.x tiene un bug donde Turbopack
   muere procesando CSS en builds de producción. El script usa
   `next build --webpack` para evitarlo.

### El script (`scripts/build.sh`)

```bash
#!/bin/bash
set -e
cd "$(dirname "$0")/.."

# Step 1: Swap sqlite → mysql in schema.prisma
if grep -q 'provider = "sqlite"' prisma/schema.prisma; then
  sed -i 's/provider = "sqlite"/provider = "mysql"/' prisma/schema.prisma
fi

# Step 2: Generate Prisma client (MySQL) — no DB connection needed
npx prisma generate

# Step 3: Build with webpack (Turbopack crashes on CSS in prod)
npx next build --webpack

# Step 4: Copy static assets to standalone output
cp -r .next/static .next/standalone/.next/
cp -r public .next/standalone/
```

### Verificación local antes de deploy

```bash
# Simular el build exacto de Hostinger (sin .env, sin DATABASE_URL)
mv .env .env.bak
unset DATABASE_URL
bash scripts/build.sh
# Debe terminar con exit code 0
mv .env.bak .env

# IMPORTANTE: Después del test, regenerar el cliente Prisma para SQLite
# (el build test lo generó para MySQL)
npx prisma generate
```

### ¿Por qué `prisma generate` no necesita DB?

`prisma generate` solo lee `prisma/schema.prisma` y genera código TypeScript.
No se conecta a la base de datos. La `DATABASE_URL` se resuelve en **runtime**
(cuando `PrismaClient` se instancia al arrancar la app), no en build time.

### Páginas force-dynamic (no se pre-renderizan)

22 páginas tienen `export const dynamic = "force-dynamic"`:
- `/` (home)
- `/agregar-grupo`, `/buscar`, `/categorias`, `/paises`, `/ciudades`
- `/categoria/[slug]`, `/pais/[code]`, `/ciudad/[slug]`
- `/grupo/[slug]`, `/autor/[slug]`, `/etiqueta/[slug]`, `/verificar/[slug]`
- Todas las páginas `/admin/*`

También 9 API routes: `/rss`, `/api/categories`, `/api/countries`,
`/api/groups/{recent,trending,most-shared,top-rated,tags,ratings-batch}`

Páginas estáticas (sin DB, se pre-renderizan normalmente):
`/contacto`, `/sobre-nosotros`, `/guias`, `/politica-de-privacidad`,
`/terminos`, `/politica-de-cookies`, `/reportar-grupo`, `/enviar-grupo`
