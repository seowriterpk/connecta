/**
 * Sitemap Generator Cron — runs nightly at 2am
 * Based on Groupizo VIP Logic SYSTEM 17.
 *
 * - Generates XML sitemap files in /public/sitemaps/
 * - groups-1.xml, groups-2.xml (200 per file, never adult)
 * - categorias.xml, paises.xml, ciudades.xml, estaticas.xml
 * - sitemap.xml index pointing to all
 * - Lock file prevents overlapping
 */

import { PrismaClient } from "@prisma/client";
import { citySlug } from "../../src/lib/data";
import * as fs from "fs";
import * as path from "path";

const db = new PrismaClient();
const BASE_URL = process.env.BASE_URL || "https://conectagrupos.com";
const SITEMAPS_DIR = path.join(__dirname, "..", "..", "public", "sitemaps");
const LOCK_FILE = path.join(__dirname, "..", "..", "logs", "sitemap-gen.lock");
const LOG_FILE = path.join(__dirname, "..", "..", "logs", "sitemap-gen.log");

function log(msg: string) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  fs.appendFileSync(LOG_FILE, line + "\n");
}

async function acquireLock(): Promise<boolean> {
  if (fs.existsSync(LOCK_FILE)) {
    const content = fs.readFileSync(LOCK_FILE, "utf8");
    const ts = parseInt(content);
    if (Date.now() - ts < 30 * 60 * 1000) return false;
  }
  fs.writeFileSync(LOCK_FILE, Date.now().toString());
  return true;
}

function releaseLock() {
  if (fs.existsSync(LOCK_FILE)) fs.unlinkSync(LOCK_FILE);
}

function urlEntry(loc: string, lastmod?: string, changefreq = "weekly", priority = "0.7") {
  return `  <url>\n    <loc>${loc}</loc>\n${lastmod ? `    <lastmod>${lastmod}</lastmod>\n` : ""}    <changefreq>${changefreq}</changefreq>\n    <priority>${priority}</priority>\n  </url>`;
}

function writeSitemap(filename: string, urls: string[]) {
  const content = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>`;
  fs.writeFileSync(path.join(SITEMAPS_DIR, filename), content);
  log(`Wrote ${filename} (${urls.length} URLs)`);
}

async function main() {
  log("Starting sitemap generator cron...");

  if (!(await acquireLock())) {
    log("Another instance is running. Exiting.");
    process.exit(0);
  }

  if (!fs.existsSync(SITEMAPS_DIR)) {
    fs.mkdirSync(SITEMAPS_DIR, { recursive: true });
  }

  try {
    // Groups (never adult, 200 per file)
    const groups = await db.group.findMany({
      where: { status: "live", isAdult: false },
      orderBy: { updatedAt: "desc" },
      select: { slug: true, updatedAt: true },
    });

    const batchSize = 200;
    const sitemapFiles: { filename: string; lastmod: string }[] = [];

    for (let i = 0; i < groups.length; i += batchSize) {
      const batch = groups.slice(i, i + batchSize);
      const fileNum = Math.floor(i / batchSize) + 1;
      const filename = `grupos-${fileNum}.xml`;
      const urls = batch.map((g) =>
        urlEntry(`${BASE_URL}/grupo/${g.slug}`, g.updatedAt.toISOString().slice(0, 10), "weekly", "0.8")
      );
      writeSitemap(filename, urls);
      sitemapFiles.push({ filename, lastmod: new Date().toISOString().slice(0, 10) });
    }

    // Categories
    const categories = await db.category.findMany({ where: { isActive: true }, select: { slug: true } });
    writeSitemap("categorias.xml", categories.map((c) => urlEntry(`${BASE_URL}/categoria/${c.slug}`, undefined, "weekly", "0.9")));

    // Countries
    const countries = await db.country.findMany({ where: { isActive: true }, select: { code: true } });
    writeSitemap("paises.xml", countries.map((c) => urlEntry(`${BASE_URL}/pais/${c.code}`, undefined, "weekly", "0.9")));

    // Cities (only those with groups)
    const cityGroups = await db.group.findMany({ where: { status: "live", isAdult: false, city: { not: null } }, select: { city: true }, distinct: ["city"] });
    writeSitemap("ciudades.xml", cityGroups.map((c) => urlEntry(`${BASE_URL}/ciudad/${citySlug(c.city!)}`, undefined, "weekly", "0.8")));

    // Static pages
    writeSitemap("estaticas.xml", [
      urlEntry(`${BASE_URL}/`, undefined, "daily", "1.0"),
      urlEntry(`${BASE_URL}/agregar-grupo`, undefined, "monthly", "0.6"),
      urlEntry(`${BASE_URL}/sobre-nosotros`, undefined, "monthly", "0.6"),
      urlEntry(`${BASE_URL}/guias`, undefined, "monthly", "0.6"),
      urlEntry(`${BASE_URL}/contacto`, undefined, "monthly", "0.5"),
      urlEntry(`${BASE_URL}/politica-de-privacidad`, undefined, "yearly", "0.3"),
      urlEntry(`${BASE_URL}/terminos`, undefined, "yearly", "0.3"),
      urlEntry(`${BASE_URL}/politica-de-cookies`, undefined, "yearly", "0.3"),
      urlEntry(`${BASE_URL}/reportar-grupo`, undefined, "monthly", "0.5"),
    ]);

    // Sitemap index
    const allFiles = [
      ...sitemapFiles.map((f) => ({ ...f, type: "grupos" })),
      { filename: "categorias.xml", lastmod: new Date().toISOString().slice(0, 10), type: "categorias" },
      { filename: "paises.xml", lastmod: new Date().toISOString().slice(0, 10), type: "paises" },
      { filename: "ciudades.xml", lastmod: new Date().toISOString().slice(0, 10), type: "ciudades" },
      { filename: "estaticas.xml", lastmod: new Date().toISOString().slice(0, 10), type: "estaticas" },
    ];

    const indexContent = `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${allFiles
      .map((f) => `  <sitemap>\n    <loc>${BASE_URL}/sitemaps/${f.filename}</loc>\n    <lastmod>${f.lastmod}</lastmod>\n  </sitemap>`)
      .join("\n")}\n</sitemapindex>`;

    fs.writeFileSync(path.join(SITEMAPS_DIR, "..", "sitemap.xml"), indexContent);
    log(`Wrote sitemap.xml index (${allFiles.length} sub-sitemaps)`);

    log(`Sitemap generation complete. Total groups: ${groups.length}`);
  } finally {
    releaseLock();
    await db.$disconnect();
  }
}

main().catch((e) => {
  log(`FATAL: ${e.message}`);
  releaseLock();
  process.exit(1);
});
