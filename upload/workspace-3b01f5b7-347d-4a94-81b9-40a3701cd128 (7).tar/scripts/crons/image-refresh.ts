/**
 * Image Refresh Cron — runs every 10 minutes
 * Based on Groupizo VIP Logic SYSTEM 3.
 *
 * - Picks 60 groups where image_refreshed_at < 2 hours ago (or NULL)
 * - Re-fetches og:image from WhatsApp invite URL
 * - Downloads + compresses with sharp (300x300 JPEG 80%)
 * - Saves locally to /public/uploads/group_images/
 * - Lock file prevents overlapping
 */

import { PrismaClient } from "@prisma/client";
import { fetchWhatsAppMeta } from "../../src/lib/whatsapp-validator";
import * as fs from "fs";
import * as path from "path";

const db = new PrismaClient();
const LOCK_FILE = path.join(__dirname, "..", "..", "logs", "image-refresh.lock");
const LOG_FILE = path.join(__dirname, "..", "..", "logs", "image-refresh.log");
const UPLOAD_DIR = path.join(__dirname, "..", "..", "public", "uploads", "group_images");

function log(msg: string) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  fs.appendFileSync(LOG_FILE, line + "\n");
}

async function acquireLock(): Promise<boolean> {
  if (fs.existsSync(LOCK_FILE)) {
    const content = fs.readFileSync(LOCK_FILE, "utf8");
    const ts = parseInt(content);
    if (Date.now() - ts < 10 * 60 * 1000) return false;
  }
  fs.writeFileSync(LOCK_FILE, Date.now().toString());
  return true;
}

function releaseLock() {
  if (fs.existsSync(LOCK_FILE)) fs.unlinkSync(LOCK_FILE);
}

async function downloadAndCompress(url: string, groupId: string): Promise<string | null> {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) return null;
    const buffer = Buffer.from(await res.arrayBuffer());

    // Use sharp if available, otherwise just save raw
    let sharp: any;
    try {
      sharp = (await import("sharp")).default;
    } catch {
      sharp = null;
    }
    const filename = `group_${groupId}_${Date.now()}.jpg`;
    const filepath = path.join(UPLOAD_DIR, filename);

    if (sharp) {
      await sharp(buffer)
        .resize(300, 300, { fit: "cover" })
        .jpeg({ quality: 80 })
        .toFile(filepath);
    } else {
      fs.writeFileSync(filepath, buffer);
    }

    return `/uploads/group_images/${filename}`;
  } catch {
    return null;
  }
}

async function main() {
  log("Starting image refresh cron...");

  if (!(await acquireLock())) {
    log("Another instance is running. Exiting.");
    process.exit(0);
  }

  // Ensure upload dir exists
  if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  }

  try {
    const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000);
    const groups = await db.group.findMany({
      where: {
        status: "live",
        linkStatus: "active",
        OR: [
          { imageRefreshedAt: null },
          { imageRefreshedAt: { lt: twoHoursAgo } },
        ],
      },
      orderBy: { imageRefreshedAt: "asc" },
      take: 60,
      select: { id: true, joinLink: true },
    });

    log(`Processing ${groups.length} groups for image refresh...`);

    let refreshed = 0;
    let failed = 0;

    for (const group of groups) {
      try {
        const meta = await fetchWhatsAppMeta(group.joinLink);
        if (meta.status === "active" && meta.imageUrl) {
          const localPath = await downloadAndCompress(meta.imageUrl, group.id);
          if (localPath) {
            await db.group.update({
              where: { id: group.id },
              data: { profileImage: localPath, imageRefreshedAt: new Date() },
            });
            refreshed++;
          } else {
            failed++;
          }
        } else {
          // Link revoked or no image — update timestamp to skip next time
          await db.group.update({
            where: { id: group.id },
            data: { imageRefreshedAt: new Date() },
          });
        }
      } catch {
        failed++;
      }
    }

    log(`Image refresh done. Refreshed: ${refreshed} | Failed: ${failed}`);
  } finally {
    releaseLock();
    await db.$disconnect();
  }
}

main().catch((e) => {
  log(`FATAL: ${e.message}`);
  releaseLock();
  process.exit(1);
});
