/**
 * Link Checker Cron — runs every 6 hours
 * Based on Groupizo VIP Logic SYSTEM 2 (Parallel Bulk Checking).
 *
 * - Checks 150 groups (oldest validated first)
 * - Uses Promise.allSettled for parallel requests
 * - 3-state: active / revoked / unknown (skip on error)
 * - Lock file prevents overlapping runs
 * - Logs to /logs/link-checker.log
 */

import { PrismaClient } from "@prisma/client";
import { fetchWhatsAppMeta } from "../../src/lib/whatsapp-validator";
import * as fs from "fs";
import * as path from "path";

const db = new PrismaClient();
const LOCK_FILE = path.join(__dirname, "..", "..", "logs", "link-checker.lock");
const LOG_FILE = path.join(__dirname, "..", "..", "logs", "link-checker.log");

function log(msg: string) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  fs.appendFileSync(LOG_FILE, line + "\n");
}

async function acquireLock(): Promise<boolean> {
  if (fs.existsSync(LOCK_FILE)) {
    const content = fs.readFileSync(LOCK_FILE, "utf8");
    const ts = parseInt(content);
    if (Date.now() - ts < 10 * 60 * 1000) {
      log("Another instance is running. Exiting.");
      return false;
    }
    log("Stale lock detected. Removing.");
  }
  fs.writeFileSync(LOCK_FILE, Date.now().toString());
  return true;
}

function releaseLock() {
  if (fs.existsSync(LOCK_FILE)) fs.unlinkSync(LOCK_FILE);
}

async function checkGroup(group: { id: string; joinLink: string }) {
  try {
    const meta = await fetchWhatsAppMeta(group.joinLink);
    return { groupId: group.id, status: meta.status };
  } catch {
    return { groupId: group.id, status: "unknown" as const };
  }
}

async function main() {
  log("Starting link checker cron...");

  if (!(await acquireLock())) {
    process.exit(0);
  }

  try {
    // Pull 150 groups, oldest validated first
    const groups = await db.group.findMany({
      where: { status: "live", linkStatus: "active" },
      orderBy: { lastValidatedAt: "asc" },
      take: 150,
      select: { id: true, joinLink: true },
    });

    log(`Checking ${groups.length} groups in parallel...`);

    // Run all checks in parallel
    const results = await Promise.allSettled(
      groups.map((g) => checkGroup(g))
    );

    let active = 0;
    let revoked = 0;
    let skipped = 0;

    for (const r of results) {
      if (r.status === "fulfilled") {
        const { groupId, status } = r.value;
        if (status === "active") {
          await db.group.update({
            where: { id: groupId },
            data: { linkStatus: "active", lastValidatedAt: new Date() },
          });
          active++;
        } else if (status === "revoked") {
          await db.group.update({
            where: { id: groupId },
            data: {
              linkStatus: "revoked",
              profileImage: null, // reset image (CDN expired)
              lastValidatedAt: new Date(),
            },
          });
          revoked++;
        } else {
          // unknown — skip, just update validated timestamp
          await db.group.update({
            where: { id: groupId },
            data: { lastValidatedAt: new Date() },
          });
          skipped++;
        }
      } else {
        skipped++;
      }
    }

    log(`Batch done. Active: ${active} | Revoked: ${revoked} | Skipped: ${skipped}`);
  } finally {
    releaseLock();
    await db.$disconnect();
  }
}

main().catch((e) => {
  log(`FATAL: ${e.message}`);
  releaseLock();
  process.exit(1);
});
