/**
 * Drip Feed Cron — runs every 15 minutes
 * Based on Groupizo VIP Logic SYSTEM 7 (Round-Robin Smart Queue).
 *
 * - Takes 5 groups from groups_queue (diverse by category+country)
 * - Generates unique SEO slug
 * - Inserts into groups table with status="live"
 * - Deletes from queue
 * - Duplicate defense: checks join_link before inserting
 */

import { PrismaClient } from "@prisma/client";
import { generateSlug, makeUniqueSlug } from "../../src/lib/slug";
import * as fs from "fs";
import * as path from "path";

const db = new PrismaClient();
const LOCK_FILE = path.join(__dirname, "..", "..", "logs", "drip-feed.lock");
const LOG_FILE = path.join(__dirname, "..", "..", "logs", "drip-feed.log");

function log(msg: string) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  fs.appendFileSync(LOG_FILE, line + "\n");
}

async function acquireLock(): Promise<boolean> {
  if (fs.existsSync(LOCK_FILE)) {
    const content = fs.readFileSync(LOCK_FILE, "utf8");
    const ts = parseInt(content);
    if (Date.now() - ts < 10 * 60 * 1000) return false;
  }
  fs.writeFileSync(LOCK_FILE, Date.now().toString());
  return true;
}

function releaseLock() {
  if (fs.existsSync(LOCK_FILE)) fs.unlinkSync(LOCK_FILE);
}

async function main() {
  log("Starting drip feed cron...");

  if (!(await acquireLock())) {
    log("Another instance is running. Exiting.");
    process.exit(0);
  }

  try {
    // Round-robin: take 1 from each unique category+country combination
    const queueItems = await db.groupsQueue.findMany({
      orderBy: [{ addedAt: "asc" }],
      take: 50, // fetch more than 5 to ensure diversity
    });

    if (queueItems.length === 0) {
      log("Queue empty. Nothing to publish.");
      return;
    }

    // Group by category+country, take 1 from each, up to 5 total
    const seen = new Set<string>();
    const selected: typeof queueItems = [];
    for (const item of queueItems) {
      const key = `${item.category}__${item.country}`;
      if (!seen.has(key)) {
        seen.add(key);
        selected.push(item);
        if (selected.length >= 5) break;
      }
    }

    log(`Selected ${selected.length} groups for publishing (diverse).`);

    for (const item of selected) {
      try {
        // Duplicate defense
        const existing = await db.group.findFirst({
          where: { joinLink: { contains: item.joinLink.split("/").pop() ?? "" } },
          select: { id: true },
        });

        if (existing) {
          await db.groupsQueue.delete({ where: { id: item.id } });
          log(`Duplicate killed: ${item.groupName}`);
          continue;
        }

        // Generate slug
        let slug: string;
        if (item.isAdult) {
          // Adult: use invite code only (keeps keywords out of URL)
          const code = item.joinLink.split("/").pop() ?? "group";
          slug = `invite-${code.slice(0, 8)}`;
        } else {
          const base = generateSlug(`${item.groupName} invite link`);
          const existingSlugs = await db.group.findMany({
            where: { slug: { startsWith: base } },
            select: { slug: true },
          });
          const existingSet = new Set(existingSlugs.map((g) => g.slug));
          slug = makeUniqueSlug(base, (s) => existingSet.has(s));
        }

        // Insert into groups table
        const group = await db.group.create({
          data: {
            groupName: item.groupName,
            slug,
            joinLink: item.joinLink,
            description: item.description,
            category: item.category,
            categoryId: item.category, // assume category ID = name for now
            country: item.country,
            countryId: item.country,
            city: item.city,
            keywords: item.keywords,
            tags: item.tags,
            profileImage: item.profileImage,
            language: item.language,
            status: "live",
            linkStatus: "active",
            isAdult: item.isAdult,
            submitSource: "staff",
            uploaderId: item.uploaderId,
            lastActiveAt: new Date(),
            lastValidatedAt: new Date(),
            imageRefreshedAt: new Date(),
          },
        });

        await db.groupsQueue.delete({ where: { id: item.id } });
        log(`Published: '${item.groupName}' [slug: ${slug}]`);
      } catch (e: any) {
        log(`Error publishing '${item.groupName}': ${e.message}`);
      }
    }

    log("Drip feed complete.");
  } finally {
    releaseLock();
    await db.$disconnect();
  }
}

main().catch((e) => {
  log(`FATAL: ${e.message}`);
  releaseLock();
  process.exit(1);
});
