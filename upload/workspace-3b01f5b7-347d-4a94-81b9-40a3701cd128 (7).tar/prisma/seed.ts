// GruposWhatsApp — Seed data (Groupizo-compatible)
// Run: bun run prisma/seed.ts

import { PrismaClient } from "@prisma/client";
import { generateSlug } from "../src/lib/slug";

const db = new PrismaClient();

// ---------------------------------------------------------------------------
// CATEGORIES (20) — with isAdult, isActive, source
// ---------------------------------------------------------------------------
const categories = [
  { id: "amistad", name: "Amistad y Relaciones", icon: "💬", color: "rose", isAdult: false },
  { id: "entretenimiento", name: "Entretenimiento", icon: "🎭", color: "fuchsia", isAdult: false },
  { id: "educacion", name: "Educación y Estudios", icon: "📚", color: "sky", isAdult: false },
  { id: "tecnologia", name: "Tecnología", icon: "💻", color: "slate", isAdult: false },
  { id: "negocios", name: "Negocios y Emprendimiento", icon: "📈", color: "emerald", isAdult: false },
  { id: "salud", name: "Salud y Bienestar", icon: "🧘", color: "teal", isAdult: false },
  { id: "deportes", name: "Deportes", icon: "⚽", color: "lime", isAdult: false },
  { id: "musica", name: "Música", icon: "🎵", color: "violet", isAdult: false },
  { id: "cine", name: "Cine y Series", icon: "🎬", color: "amber", isAdult: false },
  { id: "humor", name: "Humor y Memes", icon: "😂", color: "yellow", isAdult: false },
  { id: "noticias", name: "Noticias", icon: "📰", color: "stone", isAdult: false },
  { id: "compraventa", name: "Compra-Venta", icon: "🛍️", color: "orange", isAdult: false },
  { id: "cocina", name: "Recetas y Cocina", icon: "🍳", color: "red", isAdult: false },
  { id: "viajes", name: "Viajes", icon: "✈️", color: "cyan", isAdult: false },
  { id: "videojuegos", name: "Videojuegos", icon: "🎮", color: "indigo", isAdult: false },
  { id: "empleo", name: "Empleo y Trabajo", icon: "💼", color: "blue", isAdult: false },
  { id: "arte", name: "Arte y Diseño", icon: "🎨", color: "pink", isAdult: false },
  { id: "mascotas", name: "Animales y Mascotas", icon: "🐾", color: "green", isAdult: false },
  { id: "religion", name: "Religión y Espiritualidad", icon: "🕊️", color: "purple", isAdult: false },
  { id: "idiomas", name: "Idiomas", icon: "🗣️", color: "indigo", isAdult: false },
];

// ---------------------------------------------------------------------------
// COUNTRIES (20 Spanish-speaking)
// ---------------------------------------------------------------------------
const countries = [
  { id: "es", name: "España", nameEs: "España", code: "es", flag: "🇪🇸", region: "Europa", dialCode: "+34" },
  { id: "mx", name: "Mexico", nameEs: "México", code: "mx", flag: "🇲🇽", region: "América del Norte", dialCode: "+52" },
  { id: "ar", name: "Argentina", nameEs: "Argentina", code: "ar", flag: "🇦🇷", region: "América del Sur", dialCode: "+54" },
  { id: "co", name: "Colombia", nameEs: "Colombia", code: "co", flag: "🇨🇴", region: "América del Sur", dialCode: "+57" },
  { id: "pe", name: "Peru", nameEs: "Perú", code: "pe", flag: "🇵🇪", region: "América del Sur", dialCode: "+51" },
  { id: "cl", name: "Chile", nameEs: "Chile", code: "cl", flag: "🇨🇱", region: "América del Sur", dialCode: "+56" },
  { id: "ve", name: "Venezuela", nameEs: "Venezuela", code: "ve", flag: "🇻🇪", region: "América del Sur", dialCode: "+58" },
  { id: "ec", name: "Ecuador", nameEs: "Ecuador", code: "ec", flag: "🇪🇨", region: "América del Sur", dialCode: "+593" },
  { id: "gt", name: "Guatemala", nameEs: "Guatemala", code: "gt", flag: "🇬🇹", region: "América Central", dialCode: "+502" },
  { id: "cu", name: "Cuba", nameEs: "Cuba", code: "cu", flag: "🇨🇺", region: "Caribe", dialCode: "+53" },
  { id: "bo", name: "Bolivia", nameEs: "Bolivia", code: "bo", flag: "🇧🇴", region: "América del Sur", dialCode: "+591" },
  { id: "do", name: "Republica Dominicana", nameEs: "República Dominicana", code: "do", flag: "🇩🇴", region: "Caribe", dialCode: "+1" },
  { id: "hn", name: "Honduras", nameEs: "Honduras", code: "hn", flag: "🇭🇳", region: "América Central", dialCode: "+504" },
  { id: "py", name: "Paraguay", nameEs: "Paraguay", code: "py", flag: "🇵🇾", region: "América del Sur", dialCode: "+595" },
  { id: "sv", name: "El Salvador", nameEs: "El Salvador", code: "sv", flag: "🇸🇻", region: "América Central", dialCode: "+503" },
  { id: "ni", name: "Nicaragua", nameEs: "Nicaragua", code: "ni", flag: "🇳🇮", region: "América Central", dialCode: "+505" },
  { id: "cr", name: "Costa Rica", nameEs: "Costa Rica", code: "cr", flag: "🇨🇷", region: "América Central", dialCode: "+506" },
  { id: "pa", name: "Panama", nameEs: "Panamá", code: "pa", flag: "🇵🇦", region: "América Central", dialCode: "+507" },
  { id: "uy", name: "Uruguay", nameEs: "Uruguay", code: "uy", flag: "🇺🇾", region: "América del Sur", dialCode: "+598" },
  { id: "pr", name: "Puerto Rico", nameEs: "Puerto Rico", code: "pr", flag: "🇵🇷", region: "Caribe", dialCode: "+1" },
];

// ---------------------------------------------------------------------------
// UPLOADERS (staff authors — E-E-A-T)
// ---------------------------------------------------------------------------
const uploaders = [
  {
    id: "up_lucia",
    name: "Lucía Martínez",
    slug: "lucia-martinez",
    jobTitle: "Curadora de Comunidades",
    description: "Especialista en redes sociales y comunidades hispanohablantes. Lucía explora y verifica grupos de WhatsApp desde 2021, con foco en comunidades de amistad, cultura y café.",
    facebookUrl: "https://facebook.com/lucia.martinez",
    twitterUrl: "https://twitter.com/lucia_martinez",
    linkedinUrl: "https://linkedin.com/in/luciamartinez",
    websiteUrl: null,
    imageUrl: "https://i.pravatar.cc/300?img=47",
  },
  {
    id: "up_diego",
    name: "Diego Hernández",
    slug: "diego-hernandez",
    jobTitle: "Editor de Tecnología",
    description: "Desarrollador y entusiasta de la tecnología. Diego curar grupos de programación, gadgets y emprendimiento digital en Latinoamérica.",
    facebookUrl: null,
    twitterUrl: "https://twitter.com/diego_h",
    linkedinUrl: "https://linkedin.com/in/diegohernandez",
    websiteUrl: "https://diegohernandez.dev",
    imageUrl: "https://i.pravatar.cc/300?img=12",
  },
  {
    id: "up_maria",
    name: "María González",
    slug: "maria-gonzalez",
    jobTitle: "Curadora de Cocina y Cultura",
    description: "Apasionada por la gastronomía y las tradiciones locales. María mantiene vivos los grupos de cocina casera, recetas tradicionales y viajes.",
    facebookUrl: "https://facebook.com/maria.gonzalez.cocina",
    twitterUrl: null,
    linkedinUrl: null,
    websiteUrl: "https://maria-cocina.blog",
    imageUrl: "https://i.pravatar.cc/300?img=45",
  },
  {
    id: "up_carlos",
    name: "Carlos Ramírez",
    slug: "carlos-ramirez",
    jobTitle: "Editor de Deportes y Gaming",
    description: "Periodista deportivo y gamer. Carlos cubre fútbol, running y comunidades de videojuegos en toda Hispanoamérica.",
    facebookUrl: "https://facebook.com/carlos.ramirez.sports",
    twitterUrl: "https://twitter.com/carlos_ramirez",
    linkedinUrl: "https://linkedin.com/in/carlosramirez",
    websiteUrl: null,
    imageUrl: "https://i.pravatar.cc/300?img=33",
  },
];

// ---------------------------------------------------------------------------
// GROUPS (30 demo, original Spanish content)
// ---------------------------------------------------------------------------
type SeedGroup = {
  groupName: string;
  description: string;
  joinLink: string;
  profileImage: string;
  category: string;
  country: string;
  city: string;
  tags: string[];
  keywords: string[];
  members: number;
  views: number;
  clicks: number;
  isFeatured: boolean;
  uploaderId: string;
  language?: string;
};

const groups: SeedGroup[] = [
  {
    groupName: "Amigos del Café ☕ Mañanas sin prisa",
    description: "Un grupo tranquilo para empezar el día con un buen café y buena charla. Compartimos rutinas matutinas, recetas de café y, sobre todo, compañía. Sin discursos políticos, sin drama. Solo gente que disfruta hablar despacio antes de empezar a trabajar.",
    joinLink: "https://chat.whatsapp.com/cafe-manana-madrid",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/cafe-madrid.jpg",
    category: "amistad", country: "es", city: "Madrid",
    tags: ["charlar", "mañanas", "café", "tranquilo"], keywords: ["amigos", "cafe", "madrid", "mañanas"],
    members: 318, views: 5, clicks: 3, isFeatured: true, uploaderId: "up_lucia",
  },
  {
    groupName: "Mexico Lindo — Haz Amigos CDMX",
    description: "Chavos y chavas de toda la república, pero con sede en la capital. Organizamos cafés los fines de semana y planes casuales. Si acabas de llegar a la ciudad o simplemente quieres ampliar tu círculo, este es tu lugar.",
    joinLink: "https://chat.whatsapp.com/cdmx-amigos-mx",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/cdmx.jpg",
    category: "amistad", country: "mx", city: "Ciudad de México",
    tags: ["cdmx", "amigos", "planes", "casual"], keywords: ["mexico", "cdmx", "amigos", "sociedad"],
    members: 742, views: 12, clicks: 8, isFeatured: true, uploaderId: "up_diego",
  },
  {
    groupName: "Solteros 30+ Argentina — charlas reales",
    description: "Para quienes pasamos los treinta y no tenemos tiempo de apps de citas. Aquí se conversa sin presión, se comparten planes y, si surge, surge. Grupo con reglas claras y respeto antes que nada.",
    joinLink: "https://chat.whatsapp.com/solteros-30-ar",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/solteros-ba.jpg",
    category: "amistad", country: "ar", city: "Buenos Aires",
    tags: ["solteros", "30+", "charlar"], keywords: ["argentina", "solteros", "buenos-aires"],
    members: 521, views: 8, clicks: 5, isFeatured: false, uploaderId: "up_lucia",
  },
  {
    groupName: "Cine Clásico — de Hitchcock a Almodóvar",
    description: "Cada semana proponemos una película, la vemos y debatimos. Desde el suspense de los 60 hasta el cine español contemporáneo. Sin spoilers la primera semana, después se vale todo.",
    joinLink: "https://chat.whatsapp.com/cine-clasico-es",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/cine.jpg",
    category: "cine", country: "es", city: "Madrid",
    tags: ["cine", "clásico", "debate", "películas"], keywords: ["cine", "peliculas", "españa"],
    members: 289, views: 4, clicks: 2, isFeatured: true, uploaderId: "up_lucia",
  },
  {
    groupName: "Series Netflix — sin spoilers (bueno, un poco)",
    description: "Seguimos los estrenos semana a semana. Sección aparte para spoilers para no arruinarle la serie a nadie. Recomendamos joyas escondidas que no aparecen en portada.",
    joinLink: "https://chat.whatsapp.com/series-netflix-mx",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/netflix.jpg",
    category: "cine", country: "mx", city: "Ciudad de México",
    tags: ["netflix", "series", "estrenos"], keywords: ["netflix", "series", "streaming"],
    members: 1053, views: 15, clicks: 11, isFeatured: false, uploaderId: "up_diego",
  },
  {
    groupName: "Estudiantes UNAM — apuntes y dudas",
    description: "Comunidad de la Universidad Nacional para compartir apuntes, resolver dudas y organizar sesiones de estudio. Apoyamos especialmente a los de primer ingreso que aún se pierden por Ciudad Universitaria.",
    joinLink: "https://chat.whatsapp.com/unam-estudiantes",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/unam.jpg",
    category: "educacion", country: "mx", city: "Ciudad de México",
    tags: ["unam", "apuntes", "estudio", "universidad"], keywords: ["educacion", "unam", "mexico"],
    members: 884, views: 9, clicks: 7, isFeatured: true, uploaderId: "up_diego",
  },
  {
    groupName: "Becas España 2026 — info y experiencia",
    description: "Quienes ya conseguimos beca ayudamos a los que vienen detrás. Compartimos convocatorias, requisitos y, sobre todo, la parte que no sale en los folletos: cómo es realmente vivir la experiencia.",
    joinLink: "https://chat.whatsapp.com/becas-espana-madrid",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/becas.jpg",
    category: "educacion", country: "es", city: "Madrid",
    tags: ["becas", "españa", "estudios"], keywords: ["becas", "españa", "estudiantes"],
    members: 467, views: 6, clicks: 4, isFeatured: false, uploaderId: "up_lucia",
  },
  {
    groupName: "Programadores Latam — juniors y seniors",
    description: "De juniors que recién empiezan hasta seniors que llevan años. Resolvemos dudas, hacemos code review entre todos y avisamos de ofertas de trabajo. Lengua favorita de la semana: TypeScript, pero se acepta todo.",
    joinLink: "https://chat.whatsapp.com/programadores-latam-co",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/devs.jpg",
    category: "tecnologia", country: "co", city: "Bogotá",
    tags: ["programación", "código", "trabajo", "tecnología"], keywords: ["programacion", "desarrollo", "latam"],
    members: 1392, views: 20, clicks: 14, isFeatured: true, uploaderId: "up_diego",
  },
  {
    groupName: "Gadgets y Reviews — ¿vale la pena?",
    description: "Antes de gastar, pregunta aquí. Comparamos móviles, auriculares y lo que se te ocurra. Reseñas honestas de gente que pagó de su bolsillo, sin patrocinios disimulados.",
    joinLink: "https://chat.whatsapp.com/gadgets-reviews-ar",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/gadgets.jpg",
    category: "tecnologia", country: "ar", city: "Buenos Aires",
    tags: ["gadgets", "reviews", "tecnología", "móviles"], keywords: ["tecnologia", "reviews", "argentina"],
    members: 634, views: 7, clicks: 5, isFeatured: false, uploaderId: "up_diego",
  },
  {
    groupName: "Emprendedores Perú — de idea a venta",
    description: "Para los que están empezando o ya tienen su negocio corriendo. Hablamos de precios, proveedores, redes sociales y los errores que cometimos para que tú no los repitas.",
    joinLink: "https://chat.whatsapp.com/emprendedores-peru-lima",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/emprendedores.jpg",
    category: "negocios", country: "pe", city: "Lima",
    tags: ["emprendimiento", "negocios", "perú", "ventas"], keywords: ["negocios", "peru", "emprendimiento"],
    members: 578, views: 8, clicks: 6, isFeatured: true, uploaderId: "up_diego",
  },
  {
    groupName: "Finanzas Personales Colombia — ahorra de verdad",
    description: "Presupuesto, inversión básica y métodos para dejar de gastar a fin de mes. Cero humo, cero cursos vendidos: experiencias reales de gente común ordenando sus cuentas.",
    joinLink: "https://chat.whatsapp.com/finanzas-colombia-bogota",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/finanzas.jpg",
    category: "negocios", country: "co", city: "Bogotá",
    tags: ["finanzas", "ahorro", "inversión"], keywords: ["finanzas", "colombia", "ahorro"],
    members: 921, views: 11, clicks: 9, isFeatured: false, uploaderId: "up_diego",
  },
  {
    groupName: "Running Chile — corremos juntos",
    description: "Salidas grupales en Santiago y planes virtuales para los de regiones. Rutinas para principiantes y maratón. El que llega último, paga los café (es broma, no pagamos nada).",
    joinLink: "https://chat.whatsapp.com/running-chile-stgo",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/running.jpg",
    category: "deportes", country: "cl", city: "Santiago",
    tags: ["running", "deporte", "santiago"], keywords: ["running", "chile", "deportes"],
    members: 445, views: 5, clicks: 3, isFeatured: true, uploaderId: "up_carlos",
  },
  {
    groupName: "Fútbol Ecuador — clásicos y polémicas",
    description: "Hablar de la selección, la liga local y el fútbol internacional. Debates acalorados pero con respeto. Aquí caben todos los colores de camiseta.",
    joinLink: "https://chat.whatsapp.com/futbol-ecuador-quito",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/futbol.jpg",
    category: "deportes", country: "ec", city: "Quito",
    tags: ["fútbol", "selección", "ligas"], keywords: ["futbol", "ecuador", "deportes"],
    members: 1206, views: 18, clicks: 13, isFeatured: false, uploaderId: "up_carlos",
  },
  {
    groupName: "Cocina Casera Venezuela — recetas de la abuela",
    description: "Recetas tradicionales y adaptaciones para ingredientes que se consiguen hoy. Compartimos trucos de cocina económica y postres para reuniones familiares. Las hallacas tienen su hilo en diciembre.",
    joinLink: "https://chat.whatsapp.com/cocina-venezuela-ccs",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/cocina.jpg",
    category: "cocina", country: "ve", city: "Caracas",
    tags: ["cocina", "recetas", "tradicional"], keywords: ["cocina", "venezuela", "recetas"],
    members: 612, views: 9, clicks: 7, isFeatured: true, uploaderId: "up_maria",
  },
  {
    groupName: "Repostería Sin Horno — dulces fáciles",
    description: "Postres que se hacen sin encender el horno, ideales para calor o para cocinas pequeñas. Tartas frías, mouses, trufas. Recetas paso a paso con fotos del proceso real.",
    joinLink: "https://chat.whatsapp.com/reposteria-sin-horno-do",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/reposteria.jpg",
    category: "cocina", country: "do", city: "Santo Domingo",
    tags: ["repostería", "postres", "sin horno"], keywords: ["postres", "reposteria", "rd"],
    members: 388, views: 4, clicks: 2, isFeatured: false, uploaderId: "up_maria",
  },
  {
    groupName: "Música Urbana — reggaetón y trap",
    description: "Lo último del género, debates sobre letras y conciertos. Se aceptan recomendaciones de artistas emergentes que merecen más reproducciones.",
    joinLink: "https://chat.whatsapp.com/musica-urbana-pr",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/urbana.jpg",
    category: "musica", country: "pr", city: "San Juan",
    tags: ["reggaetón", "trap", "música urbana"], keywords: ["musica", "reggaeton", "puerto-rico"],
    members: 1490, views: 22, clicks: 16, isFeatured: true, uploaderId: "up_carlos",
  },
  {
    groupName: "Rock en Español — de Soda Stereo a hoy",
    description: "Clásicos de los 80 y 90 más la nueva escena. Compartimos conciertos, rarezas y versiones en vivo que no están en Spotify.",
    joinLink: "https://chat.whatsapp.com/rock-espanol-ar",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/rock.jpg",
    category: "musica", country: "ar", city: "Buenos Aires",
    tags: ["rock", "español", "clásicos"], keywords: ["rock", "argentina", "musica"],
    members: 533, views: 6, clicks: 4, isFeatured: false, uploaderId: "up_carlos",
  },
  {
    groupName: "Memes Diario — para empezar el día riendo",
    description: "Un meme al levantarse y otro antes de dormir. Humor sano, sin ofender a nadie. Si tuviste un mal día, este grupo te levanta el ánimo.",
    joinLink: "https://chat.whatsapp.com/memes-diario-mx",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/memes.jpg",
    category: "humor", country: "mx", city: "Ciudad de México",
    tags: ["memes", "humor", "risas"], keywords: ["memes", "humor", "mexico"],
    members: 2104, views: 30, clicks: 22, isFeatured: true, uploaderId: "up_diego",
  },
  {
    groupName: "Chistes y Más — humor para todos",
    description: "Chistes cortos, largos, malos y peores. El grupo donde el groaner es bienvenido. Sin contenido ofensivo, diversión familiar.",
    joinLink: "https://chat.whatsapp.com/chistes-guatemala",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/chistes.jpg",
    category: "humor", country: "gt", city: "Ciudad de Guatemala",
    tags: ["chistes", "humor", "familia"], keywords: ["chistes", "guatemala", "humor"],
    members: 721, views: 8, clicks: 5, isFeatured: false, uploaderId: "up_lucia",
  },
  {
    groupName: "Noticias Cuba — actualidad y debate",
    description: "Información del día y espacio de debate respetuoso. Compartimos enlaces verificados y desmentimos bulos cuando los detectamos. Sin posiciones obligatorias.",
    joinLink: "https://chat.whatsapp.com/noticias-cuba-la-habana",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/noticias.jpg",
    category: "noticias", country: "cu", city: "La Habana",
    tags: ["noticias", "actualidad", "debate"], keywords: ["noticias", "cuba", "actualidad"],
    members: 854, views: 12, clicks: 8, isFeatured: false, uploaderId: "up_lucia",
  },
  {
    groupName: "Compra-Venta CDMX — segunda mano honesta",
    description: "Vende lo que ya no usas o encuentra gangas. Reglas estrictas: fotos reales, precios claros y encuentros en sitios públicos. Modera activamente para evitar estafas.",
    joinLink: "https://chat.whatsapp.com/compraventa-cdmx",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/compraventa.jpg",
    category: "compraventa", country: "mx", city: "Ciudad de México",
    tags: ["compraventa", "segunda mano", "cdmx"], keywords: ["compraventa", "mexico", "segunda-mano"],
    members: 1876, views: 25, clicks: 19, isFeatured: true, uploaderId: "up_diego",
  },
  {
    groupName: "Mercado Libre Bolivia — ofertas y trueque",
    description: "Publica lo que vendes o lo que buscas. Trueques bienvenidos. Coordinamos por ciudades y avisamos de ferias locales.",
    joinLink: "https://chat.whatsapp.com/mercado-bolivia-lp",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/mercado.jpg",
    category: "compraventa", country: "bo", city: "La Paz",
    tags: ["compraventa", "trueque", "ofertas"], keywords: ["bolivia", "compraventa", "mercado"],
    members: 493, views: 5, clicks: 3, isFeatured: false, uploaderId: "up_diego",
  },
  {
    groupName: "Viajeros España — rutas y mochileros",
    description: "Rutas de bajo presupuesto, albergues y planes fuera de lo típico. Compartimos itinerarios probados y avisos de vuelos baratos cuando los encontramos.",
    joinLink: "https://chat.whatsapp.com/viajeros-espana-madrid",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/viajeros.jpg",
    category: "viajes", country: "es", city: "Madrid",
    tags: ["viajes", "mochileros", "rutas"], keywords: ["viajes", "españa", "mochileros"],
    members: 671, views: 10, clicks: 7, isFeatured: true, uploaderId: "up_maria",
  },
  {
    groupName: "Turismo Honduras — descubre lo local",
    description: "Playas, montañas, ruinas y gastronomía. Promovemos el turismo nacional con consejos de gente que conoce cada rincón. Perfecto para planear tu próximo puente.",
    joinLink: "https://chat.whatsapp.com/turismo-honduras-tgu",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/turismo.jpg",
    category: "viajes", country: "hn", city: "Tegucigalpa",
    tags: ["turismo", "honduras", "naturaleza"], keywords: ["turismo", "honduras", "viajes"],
    members: 327, views: 4, clicks: 2, isFeatured: false, uploaderId: "up_maria",
  },
  {
    groupName: "Gamers Latam — squad y partidas",
    description: "Buscamos squad para juegos online: FPS, MOBA, battle royale. Organizamos partidas y torneos internos sin premios pero con mucha rivalidad sana.",
    joinLink: "https://chat.whatsapp.com/gamers-latam-uy",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/gamers.jpg",
    category: "videojuegos", country: "uy", city: "Montevideo",
    tags: ["gaming", "squad", "online", "fps"], keywords: ["gaming", "uruguay", "videojuegos"],
    members: 932, views: 14, clicks: 10, isFeatured: true, uploaderId: "up_carlos",
  },
  {
    groupName: "Empleos Remoto — trabajo desde casa",
    description: "Ofertas de trabajo 100% remoto para profesionales hispanohablantes. Compartimos empresas que contratan a distancia, tips para entrevistas y salarios reales.",
    joinLink: "https://chat.whatsapp.com/empleos-remoto-cr",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/empleos.jpg",
    category: "empleo", country: "cr", city: "San José",
    tags: ["empleo", "remoto", "trabajo", "freelance"], keywords: ["empleo", "remoto", "costa-rica"],
    members: 1124, views: 16, clicks: 12, isFeatured: true, uploaderId: "up_diego",
  },
  {
    groupName: "Ilustradores Latam — portafolios y feedback",
    description: "Comparte tu trabajo, pide crítica constructiva y encuentra colaboraciones. Hablamos de técnicas digitales y tradicionales. Mensual: reto de ilustración con tema.",
    joinLink: "https://chat.whatsapp.com/ilustradores-latam-ni",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/ilustra.jpg",
    category: "arte", country: "ni", city: "Managua",
    tags: ["ilustración", "arte", "diseño", "portafolio"], keywords: ["arte", "ilustracion", "nicaragua"],
    members: 402, views: 5, clicks: 3, isFeatured: false, uploaderId: "up_maria",
  },
  {
    groupName: "Amantes de los Perros — consejos y fotos",
    description: "Cuidados, educación, alimentación y muchas fotos. Resolvemos dudas de primeros tiempos y compartimos logros. Adopciones coordinadas con refugios verificados.",
    joinLink: "https://chat.whatsapp.com/amantes-perros-py",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/perros.jpg",
    category: "mascotas", country: "py", city: "Asunción",
    tags: ["perros", "mascotas", "adopción"], keywords: ["perros", "mascotas", "paraguay"],
    members: 1340, views: 19, clicks: 14, isFeatured: true, uploaderId: "up_maria",
  },
  {
    groupName: "Gatos y Más — el reinado felino",
    description: "Fotos, cuidados, curiosidades y travesuras felinas. Un grupo tranquilo para amantes de los gatos donde se comparte el día a día con nuestros mininos.",
    joinLink: "https://chat.whatsapp.com/gatos-mas-pa",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/gatos.jpg",
    category: "mascotas", country: "pa", city: "Ciudad de Panamá",
    tags: ["gatos", "mascotas", "fotos"], keywords: ["gatos", "mascotas", "panama"],
    members: 866, views: 11, clicks: 8, isFeatured: false, uploaderId: "up_maria",
  },
  {
    groupName: "Practica Inglés — intercambio hispano-anglo",
    description: "Hablamos mitad español, mitad inglés. Quienes aprenden español ayudan a quienes aprenden inglés y viceversa. Sesiones de voz semanales opcionales, sin presión.",
    joinLink: "https://chat.whatsapp.com/practica-ingles-sv",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/ingles.jpg",
    category: "idiomas", country: "sv", city: "San Salvador",
    tags: ["inglés", "intercambio", "idiomas", "conversación"], keywords: ["ingles", "idiomas", "elsalvador"],
    members: 745, views: 10, clicks: 7, isFeatured: true, uploaderId: "up_lucia",
  },
  {
    groupName: "Fe y Reflexión — comunidad espiritual",
    description: "Espacio de respeto para compartir reflexiones diarias, oraciones y apoyo mutuo. Abierto a todas las creencias que promuevan la paz y el bien común.",
    joinLink: "https://chat.whatsapp.com/fe-reflexion-es",
    profileImage: "https://pps.whatsapp.net/v/t61.24694-24/fe.jpg",
    category: "religion", country: "es", city: "Sevilla",
    tags: ["fe", "reflexión", "espiritualidad"], keywords: ["religion", "espiritualidad", "españa"],
    members: 560, views: 7, clicks: 4, isFeatured: false, uploaderId: "up_lucia",
  },
];

// ---------------------------------------------------------------------------
// SETTINGS
// ---------------------------------------------------------------------------
const settings = [
  { key: "ugc_max_submissions_per_device_day", value: "10" },
  { key: "ugc_max_submissions_per_ip_day", value: "30" },
  { key: "ugc_auto_publish_score", value: "70" },
  { key: "ugc_min_tags", value: "3" },
  { key: "ugc_min_keywords", value: "3" },
];

async function main() {
  console.log("🌱 Seeding GruposWhatsApp database...");

  // Categories
  for (let i = 0; i < categories.length; i++) {
    const c = categories[i];
    await db.category.create({
      data: {
        id: c.id,
        name: c.name,
        slug: c.id,
        description: `Comunidades de ${c.name.toLowerCase()} en WhatsApp.`,
        icon: c.icon,
        color: c.color,
        isAdult: c.isAdult,
        isActive: true,
        sortOrder: i + 1,
        source: "seed",
      },
    });
  }
  console.log(`  ✓ ${categories.length} categories`);

  // Countries
  for (const c of countries) {
    await db.country.create({
      data: {
        id: c.id,
        name: c.name,
        nameEs: c.nameEs,
        slug: c.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
        code: c.code,
        flag: c.flag,
        region: c.region,
        dialCode: c.dialCode,
        isActive: true,
      },
    });
  }
  console.log(`  ✓ ${countries.length} countries`);

  // Uploaders (authors)
  for (const u of uploaders) {
    await db.uploader.create({ data: u });
  }
  console.log(`  ✓ ${uploaders.length} uploaders (authors)`);

  // Groups
  const usedSlugs = new Set<string>();
  for (const g of groups) {
    const cat = categories.find((c) => c.id === g.category)!;
    const country = countries.find((c) => c.id === g.country)!;
    const baseSlug = generateSlug(`${g.groupName} invite link`);
    let slug = baseSlug;
    let counter = 1;
    while (usedSlugs.has(slug)) {
      slug = `${baseSlug}-${counter}`;
      counter++;
    }
    usedSlugs.add(slug);

    await db.group.create({
      data: {
        groupName: g.groupName,
        slug,
        joinLink: g.joinLink,
        description: g.description,
        category: cat.name,
        categoryId: cat.id,
        country: country.name,
        countryId: country.id,
        city: g.city,
        keywords: JSON.stringify(g.keywords),
        tags: JSON.stringify(g.tags),
        profileImage: g.profileImage,
        language: g.language ?? "Espanol",
        status: "live",
        linkStatus: "active",
        isAdult: false,
        submitSource: "staff",
        clicks: g.clicks,
        joinCount: g.clicks,
        views: g.views,
        shares: 0,
        avgRating: 0,
        ratingCount: 0,
        uploaderId: g.uploaderId,
        lastActiveAt: new Date(),
        lastValidatedAt: new Date(),
        imageRefreshedAt: new Date(),
        popularityBadge: g.members >= 1000 ? "hot" : g.isFeatured ? "featured" : null,
      },
    });
  }
  console.log(`  ✓ ${groups.length} groups`);

  // Settings
  for (const s of settings) {
    await db.setting.create({ data: { key: s.key, value: s.value } });
  }
  console.log(`  ✓ ${settings.length} settings`);

  console.log("✅ Seed complete!");
}

main()
  .catch((e) => {
    console.error("❌ Seed error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
