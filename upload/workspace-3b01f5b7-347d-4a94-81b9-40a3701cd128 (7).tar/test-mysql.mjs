import mysql from 'mysql2/promise';
const pool = mysql.createPool({
  host: '31.97.208.160', port: 3306,
  user: 'u824913874_spanish', password: 'qX8t8=++L@c*',
  database: 'u824913874_spanishs',
  waitForConnections: true, connectionLimit: 3, connectTimeout: 10000,
});
try {
  const conn = await pool.getConnection();
  console.log('CONNECTED to MySQL');
  const [rows] = await conn.query('SELECT VERSION() as v');
  console.log('MySQL version:', rows[0].v);
  const [tables] = await conn.query("SHOW TABLES");
  console.log('Tables:', tables.length);
  for (const t of tables) console.log('  -', Object.values(t)[0]);
  conn.release();
} catch (e) { console.error('FAILED:', e.message); }
finally { await pool.end(); }
